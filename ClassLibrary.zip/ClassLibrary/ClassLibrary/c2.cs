﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class c2
    {

        public string call3()
        {
            return "Call from call3";
        }
        public string call4()
        {
            return "Call from call4";
        }
    }
}
