﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
   public  class c1
    {
        public string call1()
        {
            return "hi form call1";



        }

        public string call2()
        {
            return "Hello from call2";
        }
    }
}
