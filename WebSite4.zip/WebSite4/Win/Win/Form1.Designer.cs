﻿namespace Win
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_read_type = new System.Windows.Forms.Button();
            this.btn_LoadAssembly = new System.Windows.Forms.Button();
            this.lst_class = new System.Windows.Forms.ListBox();
            this.lst_methods = new System.Windows.Forms.ListBox();
            this.btn_call = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_read_type
            // 
            this.btn_read_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_read_type.Location = new System.Drawing.Point(95, 12);
            this.btn_read_type.Name = "btn_read_type";
            this.btn_read_type.Size = new System.Drawing.Size(176, 41);
            this.btn_read_type.TabIndex = 0;
            this.btn_read_type.Text = "Read Type";
            this.btn_read_type.UseVisualStyleBackColor = true;
            this.btn_read_type.Click += new System.EventHandler(this.btn_read_type_Click);
            // 
            // btn_LoadAssembly
            // 
            this.btn_LoadAssembly.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LoadAssembly.Location = new System.Drawing.Point(95, 59);
            this.btn_LoadAssembly.Name = "btn_LoadAssembly";
            this.btn_LoadAssembly.Size = new System.Drawing.Size(176, 40);
            this.btn_LoadAssembly.TabIndex = 1;
            this.btn_LoadAssembly.Text = "Load Assembly";
            this.btn_LoadAssembly.UseVisualStyleBackColor = true;
            this.btn_LoadAssembly.Click += new System.EventHandler(this.btn_LoadAssembly_Click);
            // 
            // lst_class
            // 
            this.lst_class.FormattingEnabled = true;
            this.lst_class.Location = new System.Drawing.Point(95, 118);
            this.lst_class.Name = "lst_class";
            this.lst_class.Size = new System.Drawing.Size(176, 121);
            this.lst_class.TabIndex = 3;
            this.lst_class.SelectedIndexChanged += new System.EventHandler(this.lst_class_SelectedIndexChanged);
            // 
            // lst_methods
            // 
            this.lst_methods.FormattingEnabled = true;
            this.lst_methods.Location = new System.Drawing.Point(367, 118);
            this.lst_methods.Name = "lst_methods";
            this.lst_methods.Size = new System.Drawing.Size(159, 121);
            this.lst_methods.TabIndex = 4;
            // 
            // btn_call
            // 
            this.btn_call.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_call.Location = new System.Drawing.Point(450, 59);
            this.btn_call.Name = "btn_call";
            this.btn_call.Size = new System.Drawing.Size(95, 40);
            this.btn_call.TabIndex = 5;
            this.btn_call.Text = "call";
            this.btn_call.UseVisualStyleBackColor = true;
            this.btn_call.Click += new System.EventHandler(this.btn_call_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 261);
            this.Controls.Add(this.btn_call);
            this.Controls.Add(this.lst_methods);
            this.Controls.Add(this.lst_class);
            this.Controls.Add(this.btn_LoadAssembly);
            this.Controls.Add(this.btn_read_type);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_read_type;
        private System.Windows.Forms.Button btn_LoadAssembly;
        private System.Windows.Forms.ListBox lst_class;
        private System.Windows.Forms.ListBox lst_methods;
        private System.Windows.Forms.Button btn_call;
    }
}

