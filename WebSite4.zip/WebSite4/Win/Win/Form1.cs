﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace Win
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_read_type_Click(object sender, EventArgs e)
        {

            Type t = typeof(Test);
            MessageBox.Show(t.FullName);
            MessageBox.Show(t.Assembly.FullName);
            foreach (MethodInfo m in t.GetMethods()) 
            {
                MessageBox.Show(m.Name);

            }
        }
        Assembly asm;
        private void btn_LoadAssembly_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.ShowDialog();
            string dlladdress = dialog.FileName;
            asm = Assembly.LoadFile(dlladdress);
            MessageBox.Show(asm.FullName);
            lst_class.Items.Clear();
            foreach(Type t in asm.GetTypes())
            {
                lst_class.Items.Add(t.FullName);
            }


        }

        private void lst_class_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = lst_class.Text;
            Type t = asm.GetType(name);

            lst_methods.Items.Clear();
            foreach(MethodInfo m in t.GetMethods())
            {
                lst_methods.Items.Add(m.Name);
            }

        }

        private void btn_call_Click(object sender, EventArgs e)
        {
            Type t = asm.GetType(lst_class.Text);
            object obj = Activator.CreateInstance(t);
            MethodInfo m = t.GetMethod(lst_methods.Text);
            object retundata = m.Invoke(obj, null);
            MessageBox.Show(retundata.ToString());


        }
    }
}
