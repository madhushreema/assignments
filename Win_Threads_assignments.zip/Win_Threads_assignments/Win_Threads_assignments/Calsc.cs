﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Threads_assignments
{
    class Calsc
    {
        public Task<Double> GetCalc(double d1, double d2, string operationtype)
        {
            Task<double> t = Task.Run(() =>
              {
                  System.Threading.Thread.Sleep(3000);
                  if (operationtype == "+")
                  {
                      return d1 + d2;
                  }
                  else if (operationtype == "-")
                  {
                      return d1 - d2;
                  }
                  else
                  {
                      throw new Exception("Invalid operation:");
                  }

              });
            return t;
        }


    }
}
