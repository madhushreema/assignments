﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Deligates
{
    class Program
    {
        static void Main(string[] args)
        {
            Test obj = new Test();

            Test.del d = new Test.del(obj.call1);
          
            d += new Test.del(obj.call2);
            d -= new Test.del(obj.call1);

            d += new Test.del(obj.call1);
      
            d += delegate (string s)
              {
                  Console.WriteLine("Anonymouse Function :" + s);
              };
            d += (s) => Console.WriteLine(s);//lamda Expression


            d("Hellow Deligate");

            // d("HELLO call2");
            //Console.WriteLine(d);
            Console.ReadLine();
        }
    }
}
