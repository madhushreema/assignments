﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Win_io
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_binarywriter_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test/a.txt",FileMode.OpenOrCreate,FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            string  x = "100";
            bw.Write(x);
            bw.Flush();
            fs.Close();
            MessageBox.Show("File Created");
        }

        private void binaryReader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test/a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryReader br = new BinaryReader(fs);
            int x = br.ReadInt32();
            //  br.Flush();
            fs.Close();
            MessageBox.Show(x.ToString());
        }

        private void btn_swriter_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test/b.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
           StreamWriter bw = new StreamWriter(fs);
            string str = "Hello Dotnet";
            bw.WriteLine(str);
            bw.Flush();
            fs.Close();
            MessageBox.Show("File created"); 
        }

        private void btn_sreader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test/b.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadToEnd();
            fs.Close();
            MessageBox.Show(str);
        }
    }
}
