﻿namespace Win_io
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_binarywriter = new System.Windows.Forms.Button();
            this.binaryReader = new System.Windows.Forms.Button();
            this.btn_sreader = new System.Windows.Forms.Button();
            this.btn_swriter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_binarywriter
            // 
            this.btn_binarywriter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_binarywriter.Location = new System.Drawing.Point(65, 109);
            this.btn_binarywriter.Name = "btn_binarywriter";
            this.btn_binarywriter.Size = new System.Drawing.Size(204, 75);
            this.btn_binarywriter.TabIndex = 0;
            this.btn_binarywriter.Text = "Binary Writer";
            this.btn_binarywriter.UseVisualStyleBackColor = true;
            this.btn_binarywriter.Click += new System.EventHandler(this.btn_binarywriter_Click);
            // 
            // binaryReader
            // 
            this.binaryReader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryReader.Location = new System.Drawing.Point(65, 221);
            this.binaryReader.Name = "binaryReader";
            this.binaryReader.Size = new System.Drawing.Size(204, 54);
            this.binaryReader.TabIndex = 1;
            this.binaryReader.Text = "Binsry Reader";
            this.binaryReader.UseVisualStyleBackColor = true;
            this.binaryReader.Click += new System.EventHandler(this.binaryReader_Click);
            // 
            // btn_sreader
            // 
            this.btn_sreader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sreader.Location = new System.Drawing.Point(393, 207);
            this.btn_sreader.Name = "btn_sreader";
            this.btn_sreader.Size = new System.Drawing.Size(204, 54);
            this.btn_sreader.TabIndex = 3;
            this.btn_sreader.Text = "Stream Reader";
            this.btn_sreader.UseVisualStyleBackColor = true;
            this.btn_sreader.Click += new System.EventHandler(this.btn_sreader_Click);
            // 
            // btn_swriter
            // 
            this.btn_swriter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_swriter.Location = new System.Drawing.Point(393, 96);
            this.btn_swriter.Name = "btn_swriter";
            this.btn_swriter.Size = new System.Drawing.Size(204, 75);
            this.btn_swriter.TabIndex = 2;
            this.btn_swriter.Text = "Stream Writer";
            this.btn_swriter.UseVisualStyleBackColor = true;
            this.btn_swriter.Click += new System.EventHandler(this.btn_swriter_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 326);
            this.Controls.Add(this.btn_sreader);
            this.Controls.Add(this.btn_swriter);
            this.Controls.Add(this.binaryReader);
            this.Controls.Add(this.btn_binarywriter);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_binarywriter;
        private System.Windows.Forms.Button binaryReader;
        private System.Windows.Forms.Button btn_sreader;
        private System.Windows.Forms.Button btn_swriter;
    }
}

