﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//Add
using System.Runtime.Serialization.Formatters.Binary;//Add
using System.Xml.Serialization;

namespace Win_serialation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_serialization_Click(object sender, EventArgs e)
        {
            Product p = new Product();
            p.ProductId = Convert.ToInt32(txt_id.Text);
            p.ProductName = txt_name.Text;
            p.ProductPrice = Convert.ToInt32(txt_price.Text);

            FileStream fs = new FileStream("c:/Test/a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("Binary Serialization is done:");

        }

        private void btn_non_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/Product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            Product p = b.Deserialize(fs)as Product;
            fs.Close();
            txt_id.Text = p.ProductId.ToString();
            txt_name.Text = p.ProductName;
            txt_price.Text = p.ProductPrice.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/Product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);

            Product p= new Product();
            p.ProductId = Convert.ToInt32(txt_id.Text);
            p.ProductName = txt_name.Text;
            p.ProductPrice = Convert.ToInt32(txt_price.Text);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            xml.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("Xml serialization Done");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/Test/Prod.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            Product p = xml.Deserialize(fs) as Product;
            fs.Close();
            txt_id.Text = p.ProductId.ToString();
            txt_name.Text = p.ProductName;
            txt_price.Text = p.ProductPrice.ToString();
        }
    }
}
