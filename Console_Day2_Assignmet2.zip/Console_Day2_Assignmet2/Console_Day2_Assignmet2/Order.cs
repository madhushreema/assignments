﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Assignmet2
{
    class Order
    {

        public int OrderID;
        public   string CustomerName;
        public String ItemName;
        public int ItemPrice;
        public int ItemQty;


        public int POrederID
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string pItemName
        {
            get
            {
                return this.ItemName;
            }
        }
        public int PItemPrice
        {
            get
            {

                return this.ItemPrice;
            }
        }
        public int PItemQty
        {
            get
            {

                return this.ItemQty;
            }
        }



        private static int count = 1000;


        public Order(string CustomerName, string ItemName,int ItemPrice ,int ItemQty)
        {
            Order.count++;
            // this.OrderID = OrderID;
            this.OrderID = Order.count;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQty = ItemQty;




        }



public int Ammount()
        {
            int amt = this.ItemPrice * this.ItemQty;
            return amt;
        }




























    }
}
