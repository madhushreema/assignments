﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Assignmet2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("ENter ITEM name :");
            String ItemName = Console.ReadLine();
            Console.WriteLine("Enter ITEM PRICE :");
            int itemprice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter ITEM qty :");
            int itemQty = Convert.ToInt32(Console.ReadLine());

            Order obj = new Order(name, ItemName, itemprice,itemQty);

            int a = obj.POrederID;
            string b = obj.PCustomerName;
            String c = obj.pItemName;
            int d = obj.PItemPrice;
            int e = obj.PItemQty;

            Console.WriteLine("Order ID :" + a);
            Console.WriteLine("CustomerName :" + b);
            Console.WriteLine("Item name: " + c);
            Console.WriteLine("Item Price :" + d);
            Console.WriteLine("Item qty :" +e);

            int h = obj.Ammount();

            Console.WriteLine("Ammount :" + h);





















            Console.ReadLine();







        }
    }
}
