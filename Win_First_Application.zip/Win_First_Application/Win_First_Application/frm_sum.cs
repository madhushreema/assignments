﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class frm_sum : Form
    {
        public frm_sum()
        {
            InitializeComponent();
        }
        private void btn_Sum_Click(object sender, EventArgs e)
        {


            if (txt_Number1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number1");
            }
            else if (txt_Number2.Text == string.Empty)
            {
                MessageBox.Show("Enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_Number1.Text);
                int num2 = Convert.ToInt32(txt_Number2.Text);
                int num3 = num1 + num2;

                MessageBox.Show("Total : " + num3);

                //string number1= txt_Number1.Text;
                //string number2 = txt_Number2.Text;



                //string sum = number1 + number2;
                //MessageBox.Show(sum);


            }
        }

       

        }
    }

