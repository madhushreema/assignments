﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class frm_Controls : Form
    {
        public frm_Controls()
        {
            InitializeComponent();
        }

        private void frm_Controls_Load(object sender, EventArgs e)
        {
            lst_cities.Items.Add("Pune");
            lst_cities.Items.Add("Karnataka");
            lst_cities.Items.Add("Hyd");
            lst_cities.Items.Add("Andra");
            cmb_cities.Items.Add("Pune");
            cmb_cities.Items.Add("Karnataka");
            cmb_cities.Items.Add("Hyd");
            




        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if(rdb_male.Checked==false && rdb_female.Checked==false)
            {
                MessageBox.Show("Select Your Gender :");
            }
            else
            {
                string gender = string.Empty;
                if(rdb_male.Checked)
                {
                    gender = "male";
                }
                else
                {
                    gender = "Female";
                }
                MessageBox.Show(gender);

            }







            bool status = chk_readme.Checked;
            if(status)
            {
                MessageBox.Show("it is Checked");
            }
            else
            {
                MessageBox.Show("It is unchecked");
            }





            if(cmb_cities.Text==string.Empty)
            {
                MessageBox.Show("Select city : ");
            }
            else
            {
                string city = cmb_cities.Text;
                MessageBox.Show(city);
            }
        }

        private void cmb_cities_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
