﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Collection_Assignment
{
    class Employee
    {
        public delegate void delleave(int id, string res);
        public event delleave eventleave;
        private int Empid;
        private string EmpName;
        private string EmpCity;

        public static int count = 1000;

        public Employee(string EmpName, string EmpCity)
        {
            Employee.count++;

            this.Empid = Employee.count;
            this.EmpName = EmpName;
            this.EmpCity = EmpCity;
        }

        public int PEmpid
           {
            get{return this.Empid;} }

        public string PEmpName
        {
            get
            {
                return this.EmpName;
            }
        }
        public string PEmpCity
        { get { return this.EmpCity; } }

        public void TakeLeave(string Reason)
        {

            if(eventleave!=null)
            {
                this.eventleave(this.Empid, Reason);


            }
            Console.WriteLine("Employee on leave :" + this.Empid + " , Reason: " + Reason);
        }






    }
}
