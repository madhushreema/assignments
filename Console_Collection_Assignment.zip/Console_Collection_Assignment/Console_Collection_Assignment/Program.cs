﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Collection_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {

            Company c = new Company("LALITHA", "TUMKUR");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter your option 1.Add 2.Find 3.Remove 4.Show 5.Exit 6.Leave:");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {

                    case 1:
                        Console.WriteLine("Enter the EmpName :");
                        string name = Console.ReadLine();
                        Console.WriteLine("Entre the Emplyee City :");
                        string city = Console.ReadLine();
                        Employee e = new Employee(name, city);
                        c.addEmployee(e);
                        Console.WriteLine("Emploee Added :" + e.PEmpid);
                        break;

                    case 2:
                        Console.WriteLine("Entre Employee Id :");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Employee obj = c.find(id);
                        if (obj != null)
                        {
                            Console.WriteLine("employee Find:" + obj.PEmpName);
                        }

                        else
                        {
                            Console.WriteLine("Employee Not Found :");
                        }
                        break;


                    case 3:
                        Console.WriteLine("Enter id:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(ID);
                        if (status)
                        {
                            Console.WriteLine("Employee Removed");
                        }
                        else
                        {
                            Console.WriteLine("employee not Found");
                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;

                    case 5:
                        flag = false;

                        break;

                    case 6:
                              Console.WriteLine("Enter Employee ID:");
                          int id1 = Convert.ToInt32(Console.ReadLine());
                            Employee e1 = c.find(id1);
                         Console.WriteLine("Enter Reason :");
                         string re = Console.ReadLine();
                         e1.TakeLeave(re);
                        break;


                            




                }
            }
        }
    }
}

    