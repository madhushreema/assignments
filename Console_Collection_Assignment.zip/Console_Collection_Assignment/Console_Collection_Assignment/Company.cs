﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Collection_Assignment
{
    class Company
    {

        public void onleave(int id,string  res)

        {
            Console.WriteLine("Employee on leave: " + id +" " + res);

        }

        private string EmpName;
        private string EmpAddress;

        public Company(string EmpName,string EmpAddress)
        {
            this.EmpName = EmpName;
            this.EmpAddress = EmpAddress;
        }


        private List<Employee> EmployeeList = new List<Employee>();



        public void addEmployee(Employee e)
        {
            Employee.delleave d = new Employee.delleave(this.onleave);
            e.eventleave += d;
            EmployeeList.Add(e);
        }
        public Employee find(int Empid)
        {
            foreach (Employee e in EmployeeList)
            {
                if (e.PEmpid == Empid)
                { return e; }
            }
                return null;


            

             }

        public bool Remove(int ID)
        {
            foreach (Employee e in EmployeeList)
            {
                if (e.PEmpid == ID)
                {
                    EmployeeList.Remove(e);
                    return true;
                }
            }
            return false;





        }
        public void ShowAll()
        {

            foreach(Employee e in EmployeeList)
            {
                Console.WriteLine(e.PEmpid + " " + e.PEmpName + " " + e.PEmpCity);
            }

        }


    }
}
