﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAdditionofdigits
{
    class Program
    {
        static void Main(string[] args)
        {

            string str = "11112112";
            char[] ch = str.ToCharArray();
        //    str = new string(ch);



            
        }
    }
}
