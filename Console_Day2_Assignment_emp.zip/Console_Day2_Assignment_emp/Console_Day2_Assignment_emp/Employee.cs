﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Assignment_emp
{
    class Employee
    {
        public int EmpID;
        public string EmpName;
        public String EmpCity;
        public double EmpSalary;


        public Employee(int EmpID, string EmpName,string EmpCity,double EmpSalary)
        {
            this.EmpID = EmpID;
            this.EmpName = EmpName;
            this.EmpCity = EmpCity;
            this.EmpSalary = EmpSalary;


        }


        public double GetEmployeeSalary(int Days)
        {
            double Salary = (this.EmpSalary / 30) * Days;
             return Salary;




      }






    }
}
