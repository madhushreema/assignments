﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Assignment_emp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter EmpID :");
            int Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ENter Emp Name :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the empcity :");
            string city = Console.ReadLine();
            Console.WriteLine("Enter EmpSalary :");
            double sal = Convert.ToDouble(Console.ReadLine());


            Employee e = new Employee(Id,name,city,sal);


            Console.WriteLine("Enter the No.Of Days :");
            int day = Convert.ToInt32(Console.ReadLine());

            double ee=e.GetEmployeeSalary(day);

            Console.WriteLine("Salary :" + ee);
            Console.ReadLine();

        }
    }
}
