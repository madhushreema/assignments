﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


public class StudentDAL
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


    public int addStudent(Student s)
    {
        try
        {
            SqlCommand sql_com = new SqlCommand("proc_Addstudent1", con);
            sql_com.Parameters.AddWithValue("@name", s.StudentID);
            sql_com.Parameters.AddWithValue("@city", s.StudentName);
            sql_com.Parameters.AddWithValue("@address", s.studentImageAddress);
            sql_com.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            sql_com.Parameters.Add(retdata);
            con.Open();
            sql_com.ExecuteNonQuery();
            con.Close();
            //SqlCommand com_id = new SqlCommand("select @cid", con);
            int ID = Convert.ToInt32(retdata.Value);

            return ID;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }

    public List<Student> search(string key)
    {
        try
        {
            List<Student> list = new List<Student>();
            SqlCommand sql_com = new SqlCommand("proc_search", con);
            sql_com.Parameters.AddWithValue("@key", key);
            sql_com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = sql_com.ExecuteReader();
            while(dr.Read()
                )
            //SqlParameter retdata = new SqlParameter();

            {

                Student s = new Student();
                s.StudentID = dr.GetInt32(0);
                s.StudentName = dr.GetString(1);
                s.StudentCity = dr.GetString(2);
                s.studentImageAddress = dr.GetString(3);
                list.Add(s);
            }
            return list;

           




        }
        finally
        {

            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

    }

    public Student find(int id)
    {
        try
        {

            List<Student> std_list = new List<Student>();
            SqlCommand sql_com = new SqlCommand("proc_details", con);
                 sql_com.Parameters.AddWithValue("@id", id);


            sql_com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = sql_com.ExecuteReader();
            while (dr.Read())
           

            {

                Student s = new Student();
                s.StudentID = dr.GetInt32(0);
                s.StudentName = dr.GetString(1);
                s.StudentCity = dr.GetString(2);
                s.studentImageAddress = dr.GetString(3);
                return s;
            }
            return null;
        }
          



        
        finally
        {

            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }



    }
   

}



 



    
