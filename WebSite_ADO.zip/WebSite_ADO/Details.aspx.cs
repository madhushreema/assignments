﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {if(!IsPostBack)
        {
            string  id = Request.QueryString["id"];
            int studentid = Convert.ToInt32(id);
            StudentDAL dal = new StudentDAL();
            Student s = dal.find(studentid);

            lbl_sid.Text = s.StudentID.ToString();
            lbl_sname.Text = s.StudentName;
            lbl_city.Text = s.StudentCity;
            image_student.ImageUrl = s.studentImageAddress;
        }

    }
}