﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Assignment_Delegates
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            {
                if (txt_name.Text == string.Empty)
                {

                    MessageBox.Show("Enter name");

                }
                
                else if (txt_city.Text == string.Empty)
                {
                    MessageBox.Show("Entre city");
                }
                else if (txt_email.Text == string.Empty)

                {
                    MessageBox.Show("Enter Email");
                }
                else if (txt_add.Text == string.Empty)
                {

                    MessageBox.Show("Enter address ");
                }
                else
                {
                    string name = txt_name.Text;

                   
                    string city = txt_city.Text;
                    string address = txt_add.Text;
                    
                    string email = txt_email.Text;

                    student obj = new student();
                    obj.sname = name;

                    
                    obj.scity = city;
                    obj.sadd = address;
                   
                    obj.semail = email;



                    studentDAL dal = new studentDAL();
                    int id = dal.AddStudent(obj);
                    MessageBox.Show("Student Added :" + id);
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("Enter correct ID");
            }
            else
            {
                int Id = Convert.ToInt32(txt_id.Text);
                studentDAL dal = new studentDAL();
                student c = dal.find(Id);
                if (c != null)
                {
                    txt_name.Text = c.sname;
                    
                    txt_city.Text = c.scity;
                    txt_add.Text = c.sadd;
                    
                    txt_email.Text = c.semail;

                }
                else
                {
                    MessageBox.Show("not found");

                }

            }





















        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txt_id.Text == String.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_city.Text == string.Empty)
            {
                MessageBox.Show("Enter city");

            }
            else if (txt_add.Text == string.Empty)
            {
                MessageBox.Show("Enter address ");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                string city = txt_city.Text;
                string address = txt_add.Text;


                studentDAL dal = new studentDAL();
                bool status = dal.update(ID, city, address);
                if (status)
                {
                    MessageBox.Show("Updated");
                }
                else
                {
                    MessageBox.Show("Not Updated");
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int id = Convert.ToInt32(txt_id.Text);

                studentDAL dal = new studentDAL();
                bool status = dal.Delete(id);
                if (status)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt_id.Text = string.Empty;
            txt_name.Text = string.Empty;
            txt_add.Text = string.Empty;
            txt_email.Text = string.Empty;
            
            txt_city.Text = string.Empty;
        }
    }
}
