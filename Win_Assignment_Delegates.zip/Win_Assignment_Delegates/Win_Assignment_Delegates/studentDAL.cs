﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//Add
using System.Configuration;//DLL config

namespace Win_Assignment_Delegates
{
    class studentDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


        public int AddStudent(student std)
        {

            SqlCommand com_std_insert = new SqlCommand
                ("insert tbl_student values(@name,@city,@address,@email)", con);

            com_std_insert.Parameters.AddWithValue("@name", std.sname);
            com_std_insert.Parameters.AddWithValue("@city", std.scity);
            com_std_insert.Parameters.AddWithValue("@address", std.sadd);
            com_std_insert.Parameters.AddWithValue("@email", std.semail);
            con.Open();
            com_std_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;

        }
        public student find(int ID)
        {

            SqlCommand com_find = new SqlCommand
            ("select * from tbl_student where sid=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                student c = new student();
                c.sid = dr.GetInt32(0);
                c.sname = dr.GetString(1);

                c.scity = dr.GetString(2);
                c.sadd = dr.GetString(3);
              
                c.semail = dr.GetString(4);



                con.Close();
                return c;



            }
            else
            {
                return null;
            }
        }


        public bool update(int ID, string city, string address)
        {
            SqlCommand com_update = new SqlCommand("update tbl_student set scity=@city,sadd=@address where sid=@id", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.Parameters.AddWithValue("@address", address);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

         public bool Delete(int id)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_student where sid=@id", con);
            com_delete.Parameters.AddWithValue("@id", id);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }


















    }
}
