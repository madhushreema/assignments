﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Assignment_Delegates
{
    class student
    {


        public int sid;
        public string sname;
        public string scity;
        public string sadd;
        public string semail;
    }
}
