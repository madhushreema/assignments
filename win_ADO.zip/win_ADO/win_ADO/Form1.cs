﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ADO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_name.Text = string.Empty;
            txt_pass.Text = string.Empty;
            txt_city.Text = string.Empty;
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if(txt_name.Text==string.Empty)
            {

                MessageBox.Show("Enter name");

            }
            else if(txt_pass.Text==string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else if(txt_city.Text==string.Empty)
            {
                MessageBox.Show("Entre city");
            }

            else
            {
                string name = txt_name.Text;
                string city = txt_city.Text;
                string password = txt_pass.Text;
                Employee obj = new Employee();
                obj.EmployeeName = name;
                obj.EmployeeCity = city;
                obj.EmployeePassword = password;

                EmployeeDAL dal = new EmployeeDAL();
                int id = dal.AddEmployee(obj);
                MessageBox.Show("Employee Added :" +id);
            }
        }
    }
    }

