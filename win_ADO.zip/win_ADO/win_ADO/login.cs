﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ADO
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_id.Text);
            string password = txt_pass.Text;
            try
            {

                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Login(id, password);
                if (status)
                {
                    MessageBox.Show("Valid User");


                }
                else
                {
                    MessageBox.Show("Invalid User");
                }

            }
            catch(System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("Sql Error");
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            finally
            {

                MessageBox.Show("Finally Block");
            }
            frm_show_employee f = new frm_show_employee();
            f.Show();
        }

        private void btn_login2_Click(object sender, EventArgs e)
        {
            string id = txt_id.Text;
            string password = txt_pass.Text;

            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.LoginSqlInjuction(id, password);
            if(status)
            {
                MessageBox.Show("Valid User");
            }
            else
            {
                MessageBox.Show("Invalid User");
            }

          

        }

        private void txt_pass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_password_Click(object sender, EventArgs e)
        {

        }

        private void lbl_id_Click(object sender, EventArgs e)
        {

        }

        //private void login_Load(object sender, EventArgs e)
        //{
        //    frm_show_employee f = new frm_show_employee();
        //    f.Show();
        //}
    }
}
