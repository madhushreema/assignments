﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ADO
{
    public partial class final : Form
    {
        public final()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }

        private void btn_fnd_Click(object sender, EventArgs e)
        {
            frm_find f1 = new frm_find();
            f1.Show();
        }
    }
}
