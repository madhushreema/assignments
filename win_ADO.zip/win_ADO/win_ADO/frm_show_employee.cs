﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ADO
{
    public partial class frm_show_employee : Form
    {
        public frm_show_employee()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string city = txt_city.Text;
            List<Employee> list = dal.SearchEmployee(city);
            dg_employees.DataSource = list;
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string key = txt_search.Text;
            List<Employee> list = dal.SearchEmployee(key);
            dg_employees.DataSource = list;
        }
    }
}
