﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ADO
{
    public partial class frm_find : Form
    {
        public frm_find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("Enter correct ID");
            }
            else
            {
                int Id = Convert.ToInt32(txt_id.Text);
                EmployeeDAL dal = new EmployeeDAL();
                Employee emp = dal.Find(Id);
                if (emp != null)
                {
                    txt_name.Text = emp.EmployeeName;
                    txt_pass.Text = emp.EmployeePassword;
                    txt_city.Text = emp.EmployeeCity;
                    txt_doj.Text = emp.EmployeeDOJ.ToString();
                }
                else
                {
                    MessageBox.Show("not found");

                }

            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if(txt_id.Text==String.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if(txt_city.Text==string.Empty)
            {
                MessageBox.Show("Enter city");

            }
            else if(txt_pass.Text==string.Empty)
            {
                MessageBox.Show("Enter Password ");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                string city = txt_city.Text;
                string password = txt_pass.Text;


                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.update(ID, city, password);
                    if(status)
                {
                    MessageBox.Show("Updated");
                }
                else
                {
                    MessageBox.Show("Not Updated");
                }

            }



        }

        private void btn_delete_Click(object sender, EventArgs e)
        {

            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int id = Convert.ToInt32(txt_id.Text);

                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Delete(id);
                    if(status)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }
    }
}
