﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


public class BookDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public int AddBook(Book b)
    {
        try
        {
            SqlCommand sql_com = new SqlCommand("proc_addBook1", con);
            sql_com.Parameters.AddWithValue("@Bname", b.BookName);
            sql_com.Parameters.AddWithValue("@Aname", b.AuthorName);
            sql_com.Parameters.AddWithValue("@Bimage", b.BookImageAddress);
            sql_com.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            sql_com.Parameters.Add(retdata);
            con.Open();
            
            sql_com.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }

        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
    }




    public List<Book> search(string key)
    {
        try
        {
            List<Book> list = new List<Book>();
            SqlCommand sql_com = new SqlCommand("proc_search1", con);
            sql_com.Parameters.AddWithValue("@key", key);
            sql_com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = sql_com.ExecuteReader();
            while (dr.Read())
            {

                Book b = new Book();
                b.BookID = dr.GetInt32(0);
                b.BookName = dr.GetString(1);
                b.AuthorName = dr.GetString(2);
                b.BookImageAddress = dr.GetString(3);
                list.Add(b);


            }
            return list;




        }

        finally

        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }








    }







    }











