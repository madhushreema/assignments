﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAttribute
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    class DeveloperAttribute:Attribute
    {
        

        public string DevelpoerID { get; set; }
        public  string DeveloperName { get; set; }
        public DeveloperAttribute(string DeveloperID,string DeveloperName)
        {
            this.DevelpoerID = DeveloperID;
            this.DeveloperName = DeveloperName;


        }
    }
}
