﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ConsoleAttribute
{
    class Program
    {
        static void Main(string[] args)
        {
            //Test obj = new Test();
            //obj.call();

            Type t = typeof(Test);
          DeveloperAttribute d=  Attribute.GetCustomAttribute(t, typeof(DeveloperAttribute)) as DeveloperAttribute;

            Console.WriteLine(d.DevelpoerID + " " + d.DeveloperName);

            foreach (MethodInfo m in t.GetMethods())
            {
                DeveloperAttribute attmethod = Attribute.GetCustomAttribute(m, typeof(DeveloperAttribute))
                    as DeveloperAttribute;
                if (attmethod != null)
                {
                    Console.WriteLine(m.Name + " " + attmethod.DevelpoerID + "  " + attmethod.DeveloperName);
                }
            }
            Console.ReadLine();
        }
    }
}
