﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAttribute
{
    [Developer("1000","John")]
    class Test
    {
        [Obsolete("Not in use,Use xyz function")]
        [Developer("1002","David")]
        public void call()
        {
            Console.WriteLine("Call functio called:");
        }
        [Developer("1003", "dgd")]
        public void call2()
        {
            Console.WriteLine("Call function called");
        }
    }
}
