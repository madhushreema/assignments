﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_assignment_order
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the OrderID :");
            int Ord = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Customer Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Entre item name:");
            String ItName = Console.ReadLine();
            Console.WriteLine("Enter ItemPrice :");
            int Price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter ItemQty :");
            int Qty = Convert.ToInt32(Console.ReadLine());


            Order Or = new Order(Ord,name,ItName,Price,Qty);
           int k= Or.GetOrderAmmount();
            Or.GetDetails();
            Console.WriteLine("Ammount is:" + k);

            Console.ReadLine();


        }
    }
}
