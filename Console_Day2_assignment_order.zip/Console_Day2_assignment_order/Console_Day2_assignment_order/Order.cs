﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_assignment_order
{
    class Order
    {
        int OrderID;
        string CustomerName;
            string ItemName;
            int ItemPrice;
            int ItemQuantity;

        public Order(int OrderID,string CustomerName,string ItemName,int ItemPrice,int ItemQuantity)


        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;

        }


        public int GetOrderAmmount()
        {

           int  Amt = this.ItemQuantity * this.ItemPrice;
            return Amt;
        }

        public string GetDetails()
        {

            return this.OrderID + " " + this.CustomerName + "  " + this.ItemName + " " + ItemPrice;

        }
    }
}
