﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console_linq_xml
{
    class Program
    {
        static void Main(string[] args)
        {

            XElement order = new XElement("Orders", 
                new XElement("Order",new XElement( "OrderID", "1001"), new XElement("CustomerName", "XYZ"), new XElement("Orderamt", "20000")),

             new XElement("Oreder",new XElement("OrderID","1002"),new XElement("CustomerName","ABC"),new XElement("Orederamt","30000"))
                );

            order.Save(@"c:/xml/orders.xml");
            Console.WriteLine("XML File Created");


            //string url = @"c:\users\admin\documents\visual studio 2015\Projects\Console_linq_xml\Console_linq_xml\Customers.xml";

            //XDocument doc = XDocument.Load(url);


            //var data = from x in doc.Descendants("Customer")
            //           select new
            //           {
            //               CID = x.Element("CustomerID").Value,
            //               CNAME = x.Element("CustomerName").Value,
            //               CCITY = x.Element("CustomerCity").Value
            //           };

            //foreach(var d in data)
            //{
            //    Console.WriteLine(d.CID + " " + d.CNAME + " " + d.CCITY);
            //}

            Console.ReadLine();
              
        }
    }
}
