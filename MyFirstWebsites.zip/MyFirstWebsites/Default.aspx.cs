﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        

        if(!IsPostBack)
        {

            ddl_cities.Items.Add(new ListItem("select", " "));
            ddl_cities.Items.Add(new ListItem("BGL", "BGL"));
            ddl_cities.Items.Add(new ListItem("Chennai", "Chennai"));
            ddl_cities.Items.Add(new ListItem("Mumbai", "Mumbai"));
            lbl_test.Text = "Very first Time:";
        }
        else
        {
            lbl_test.Text = "Postback";
        }
    }

    protected void b1_Click(object sender, EventArgs e)
    {
        lbl_msg.Text = "Hello from the server : " + DateTime.Now.ToString();
        
    }

    protected void ddl_cities_SelectedIndexChanged(object sender, EventArgs e)
    {
        lbl_test.Text = ddl_cities.Text;
    }

    protected void b2_Click(object sender, EventArgs e)
    {
        string id = txt_code.Text;
        Response.Redirect("~/Home.aspx?code="+id);
       // Response.Redirect("http://")
    }
}