﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP3_Properties
{
    class Program
    {
        static void Main(string[] args)
        {

           // Console.WriteLine("Enter student ID: ");
           // int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Engter Student name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Marks: ");
            int Marks = Convert.ToInt32(Console.ReadLine());

            Student obj = new Student( name, Marks);

            int a=obj.PStudentID;
            string b = obj.PStudentName;

            int Smarks = obj.PStudentMarks;

            Student s1 = new Student("ABC", 90);
            Console.WriteLine(s1.PStudentID);

            Console.WriteLine(a + " " + b);
            obj.PStudentMarks = 10;
            Console.WriteLine(obj.PStudentMarks);

            obj.PStudentMarks = 90;
            Console.WriteLine(obj.PStudentMarks);
            Console.ReadLine();




        }
    }
}
