﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddBookPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_addbook_Click(object sender, EventArgs e)
    {
        Book b = new Book();
        b.BookName = txt_bname_c1.Text;
        b.AuthorName = txt_aname.Text;
        b.BookImage = "~/Image/" + Guid.NewGuid() + ".jpg";
        File_upload.SaveAs(Server.MapPath(b.BookImage));
        BookDAL dal = new BookDAL();
        int d = dal.AddBook(b);
    }
}