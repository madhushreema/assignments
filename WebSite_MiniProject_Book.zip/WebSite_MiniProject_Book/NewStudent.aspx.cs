﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewStudent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_imageupload_Click(object sender, EventArgs e)
    {

    }

    protected void btn_newUser_Click(object sender, EventArgs e)
    {
        Student st = new Student();
        StudentDAL dal = new StudentDAL();
        st.StudentName = txt_sname.Text;
        st.StudentEmailID = txt_email.Text;
        st.StudentPassword = txt_pass.Text;
        st.StudentImage = "~/Image/" + Guid.NewGuid() + ".jpg";
        image_file1.SaveAs(Server.MapPath(st.StudentImage));
        int d = dal.AddStudent(st);
        Response.Redirect("~/Login.aspx");

    }
}