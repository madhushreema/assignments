﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public class BookDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public int AddBook(Book b)
    {
        try
        {
            SqlCommand sql_com = new SqlCommand("proc_AddBooks1", con);
            sql_com.Parameters.AddWithValue("@BookName", b.BookName);
            sql_com.Parameters.AddWithValue("@AuthorName", b.AuthorName);
            sql_com.Parameters.AddWithValue("@BookImage", b.BookImage);
            sql_com.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            sql_com.Parameters.Add(retdata);
            con.Open();
            sql_com.ExecuteNonQuery();
            con.Close();
            int i = Convert.ToInt32(retdata.Value);
            return i;




        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }



    public List<Book> search(string key)
    {
        try
        {
            List<Book> list = new List<Book>();
            SqlCommand sql_com = new SqlCommand("proc_searchBook", con);
            sql_com.Parameters.AddWithValue("@key", key);
            sql_com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = sql_com.ExecuteReader();
            while (dr.Read())
            {

                Book b = new Book();
                b.BookID = dr.GetInt32(0);
                b.BookName = dr.GetString(1);
                b.AuthorName = dr.GetString(2);
                b.BookImage = dr.GetString(3);
                list.Add(b);


            }
            return list;




        }

        finally

        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }





    }

    public List<Book> details(int id)

    {
        try
        {

            List<Book> list = new List<Book>();
            SqlCommand sql_com = new SqlCommand("proc_showBook", con);
            sql_com.Parameters.AddWithValue("@id", id);
            sql_com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = sql_com.ExecuteReader();
            while (dr.Read())
            {

                Book b = new Book();
                b.BookID = dr.GetInt32(0);
                b.BookName = dr.GetString(1);
                b.AuthorName = dr.GetString(2);
                b.BookImage = dr.GetString(3);
                list.Add(b);


            }
            return list;




        }

        finally

        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }




    }

    public int AddTransaction(Issue1 i)
    {
        SqlCommand sql_com = new SqlCommand("proc_AddIssue", con);
        sql_com.Parameters.AddWithValue("@BookID", i.BookID);
        sql_com.Parameters.AddWithValue("@StudentID", i.StudentID);
        sql_com.Parameters.AddWithValue("@IssueStatus", i.issuestatus);
        sql_com.CommandType = CommandType.StoredProcedure;
        SqlParameter retdata = new SqlParameter();
        retdata.Direction = ParameterDirection.ReturnValue;
        sql_com.Parameters.Add(retdata);
        con.Open();
        sql_com.ExecuteNonQuery();
        con.Close();
        int id = Convert.ToInt32(retdata.Value);
        return id;




    }
    public List<Issue1> detailsissue(int id)

    {
        try
        {

            List<Issue1> list = new List<Issue1>();
            SqlCommand sql_com = new SqlCommand("proc_showIssue", con);
            sql_com.Parameters.AddWithValue("@id", id);
            sql_com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = sql_com.ExecuteReader();
            while (dr.Read())
            {

                Issue1 b = new Issue1();
                b.IssueID = dr.GetInt32(0);
                b.BookID = dr.GetInt32(1);
                b.StudentID = dr.GetInt32(2);
                
                b.issuestatus = dr.GetString(3);
                b.IssueDate = dr.GetDateTime(4);
                list.Add(b);


            }
            return list;




        }

        finally

        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }


    }
}


    