﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Console_Mutex_semaphone
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status;
            //     Mutex m = new Mutex(false, null, out status);

            Semaphore sm = new Semaphore(3, 3);

            Task t1 = Task.Run(() =>
            {
                sm.WaitOne();
              //  m.WaitOne();
                Console.WriteLine("Task 1 started :");
                Thread.Sleep(5000);
                Console.WriteLine("Task 1 is completed:");
                sm.Release();
               // m.ReleaseMutex();
            });
            Task t2 = Task.Run(() =>
              {
                  sm.WaitOne();
                //  m.WaitOne();
                  Console.WriteLine("Task 2 is started :");
                  Thread.Sleep(5000);
                  Console.WriteLine("Task 2 is completed");

                  //  m.ReleaseMutex();
                  sm.Release();
              }
                );
            Task t3 = Task.Run(() =>
            {
                sm.WaitOne();
                //  m.WaitOne();
                Console.WriteLine("Task 3 is started :");
                Thread.Sleep(5000);
                Console.WriteLine("Task 3 is completed");

                //  m.ReleaseMutex();
                sm.Release();
            }
                );
            Console.ReadLine();
        }
    }
}
