﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Con_Reflection_Library
{
    class Reflect1
    {

        public string R1()
        {
            return "Hi";
        }
    }
}
