﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inheritance
{
    class Customer
    {
        private string CustomerEmailId;
        private string CustomerName;


        public Customer( string CustomerEmailId, string CustomerName)
        {
            this.CustomerEmailId = CustomerEmailId;
            this.CustomerName = CustomerName;
            Console.WriteLine("Customer Construtor");
        }

        public string PCustomerEmailId
        {
            get
            {

                return this.CustomerEmailId;
            }
        }

        public string PCustomerName
        {


            get
            {

                return this.CustomerName;
            }
        }




    }
}
