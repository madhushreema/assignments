﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {

           // Customer c = new Customer(Eid, name);
            //Console.WriteLine(c.PCustomerEmailId + " " + c.PCustomerName);


            Console.WriteLine("Enter customer EmailID: ");
            string Eid = Console.ReadLine();
            Console.WriteLine("Enter CusomerName :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Customer Type:");
            string type = Console.ReadLine();
            if (type == "online")
            {

                Console.WriteLine("Enter Payment Type:");
                string PaymetType = Console.ReadLine();
                Console.WriteLine("Enter Delevery Address: ");
                String DeleveryAddress = Console.ReadLine();
                Customer_Online obj_online = new Customer_Online(Eid, name, type, DeleveryAddress);
               Console.WriteLine(obj_online.PCustomerEmailId+ " " +obj_online.PCustomerName+ " " + obj_online.PPaymentType + " "+obj_online.PDeleveryAddress);


            }
            else
            {

                Customer obj = new Customer(Eid, name);
                Console.WriteLine(obj.PCustomerEmailId + " " + obj.PCustomerName);




            }
            



            Console.ReadLine();
        }
    }
}
