﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inheritance
{
    class Customer_Online : Customer
    {

        private string PaymentType;
        private string DeleveryAddress;


        public Customer_Online(string CustomerEmailId,string CustomerName,string PaymentType, string DeleveryAddress)
            :base(CustomerEmailId,CustomerName)
        {
            this.PaymentType = PaymentType;
            this.DeleveryAddress = DeleveryAddress;
            Console.WriteLine("Customer Online Constructor");
        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;
            }
        }

        public string PDeleveryAddress
        {
            get
            {
                return this.DeleveryAddress;
            }
        }


    }
}
