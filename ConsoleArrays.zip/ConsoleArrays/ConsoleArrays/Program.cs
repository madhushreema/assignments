﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i=1;i<=10;++i)
            {
                for (int j = 1;j <=i; ++j)
                    
                {
                    Console.WriteLine("*");
                }
                //Console.ReadLine();
            }

            //int[] h = new int [5];
            //h[0] = 1;
            //h[1] = 2;
            //h[2] = 3;
            //h[3] = 4;
            //h[4] = 5;
            //for (int i = 1; i <=4; i++)
            //{
            //    Console.WriteLine(h[i]);
            //}
            
        }
    }
}
