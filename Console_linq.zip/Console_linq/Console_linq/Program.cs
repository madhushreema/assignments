﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer {CustomerId=1,CustomerAge=23,CustomerCity="BGL" ,CustomerName="ABC"});
            custlist.Add(new Customer { CustomerId = 2, CustomerAge = 27, CustomerCity = "GUL",CustomerName="Ganga" });

            custlist.Add(new Customer { CustomerId = 3, CustomerAge = 34, CustomerCity = "Tumkur", CustomerName = "Tanu" });
            custlist.Add(new Customer { CustomerId = 4, CustomerAge = 28, CustomerCity = "BGL", CustomerName = "Thara" });
            custlist.Add(new Customer { CustomerId = 5, CustomerAge = 45, CustomerCity = "BGL", CustomerName = "Fathima" });
            custlist.Add(new Customer { CustomerId = 6, CustomerAge = 45, CustomerCity = "Sagara", CustomerName = "Fathima" });
            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { CustomerID = 1, ItemName = "Pen", ItemPrice = 23, OrderID = 100 });
            ordlist.Add(new Order { CustomerID = 2, ItemName = "Bag", ItemPrice = 3400, OrderID = 200 });
            ordlist.Add(new Order { CustomerID = 3, ItemName = "Laptop", ItemPrice = 34000, OrderID = 300 });
            ordlist.Add(new Order { CustomerID = 4, ItemName = "Mouse", ItemPrice = 560, OrderID = 400 });
            ordlist.Add(new Order { CustomerID = 5, ItemName = "TV", ItemPrice = 890, OrderID = 500 });
            ordlist.Add(new Order { CustomerID = 1, ItemName = "TV", ItemPrice = 890, OrderID = 500 });
            ordlist.Add(new Order { CustomerID = 1, ItemName = "TV", ItemPrice = 890, OrderID = 545 });

            string city = "BGL";
            var q = from c in custlist
                    where c.CustomerCity == city
                    orderby c.CustomerAge descending, c.CustomerName ascending
                    select c;


            foreach (var x in q)
            {

                Console.WriteLine(x.CustomerId + " " + x.CustomerName + " " + x.CustomerCity);
            }



            var count = (from c in custlist
                         where c.CustomerCity == city
                         select c).Count();
            Console.WriteLine(count);


            var obj = (from c in custlist
                       where c.CustomerId == 1
                       select c).FirstOrDefault();


            //foreach(var c in obj)
            //{

            //    Console.WriteLine(obj.CustomerName + "" + obj.CustomerCity);
            //}
            if (obj != null)
            {

                Console.WriteLine(obj.CustomerId + "" + obj.CustomerName);
            }
            else
            {
                Console.WriteLine("NOt found");
            }

            var qdata = from c in custlist
                        where c.CustomerAge > 20
                        select new { CID = c.CustomerId, CNAME = c.CustomerName, CCITY = c.CustomerCity };


            foreach (var p in qdata)
            {
                Console.WriteLine(p.CID + " " + p.CNAME + " " + p.CCITY);
            }
            var joindata = from c in custlist
                           join o in ordlist
        on c.CustomerId equals o.CustomerID
                           select new { CID = c.CustomerId, CNAME = c.CustomerName, OID = o.OrderID, ItemName = o.ItemName, Price = o.ItemPrice };
            foreach(var j in joindata)
            {

                Console.WriteLine(j.CID + " " + j.CNAME + " " + j.OID + " " + j.ItemName + " " + j.Price);
           }
            Console.ReadLine();

        }
    }
}
