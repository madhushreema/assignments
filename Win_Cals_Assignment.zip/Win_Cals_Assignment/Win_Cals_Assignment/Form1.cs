﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Cals_Assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }





        private void btn_sum_Click(object sender, EventArgs e)
        {
            if (txt_n1.Text == String.Empty)
            {
                MessageBox.Show("Enter correct Number1:");
            }
            else if (txt_n2.Text == string.Empty)
            {
                MessageBox.Show("Entre Correct Number2:");
            }
            else
            {
                int n1 = Convert.ToInt32(txt_n1.Text);
                int n2 = Convert.ToInt32(txt_n2.Text);


                NumberLibrary.Calculater obj = new NumberLibrary.Calculater();
                int total = obj.GetSum(n1, n2);
                lbl_sum.Text = total.ToString();


            }
        }

        private void btn_mul_Click(object sender, EventArgs e)
        {


            if (txt_n1.Text == String.Empty)
            {
                MessageBox.Show("Enter correct Number1:");
            }
            else if (txt_n2.Text == string.Empty)
            {
                MessageBox.Show("Entre Correct Number2:");
            }
            else
            {
                int n1 = Convert.ToInt32(txt_n1.Text);
                int n2 = Convert.ToInt32(txt_n2.Text);


                NumberLibrary.Calculater obj = new NumberLibrary.Calculater();
                int total = obj.GetMul(n1, n2);
                lbl_mul.Text = total.ToString();


            }
        }

        private void btn_div_Click(object sender, EventArgs e)
        {
            if (txt_n1.Text == String.Empty)
            {
                MessageBox.Show("Enter correct Number1:");
            }
            else if (txt_n2.Text == string.Empty)
            {
                MessageBox.Show("Entre Correct Number2:");
            }
            else
            {
                int n1 = Convert.ToInt32(txt_n1.Text);
                int n2 = Convert.ToInt32(txt_n2.Text);


                NumberLibrary.Calculater obj = new NumberLibrary.Calculater();
                double total = obj.GetDivide(n1, n2);
                lbl_div.Text = total.ToString();


            }
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            if (txt_n1.Text == String.Empty)
            {
                MessageBox.Show("Enter correct Number1:");
            }
            else if (txt_n2.Text == string.Empty)
            {
                MessageBox.Show("Entre Correct Number2:");
            }
            else
            {
                int n1 = Convert.ToInt32(txt_n1.Text);
                int n2 = Convert.ToInt32(txt_n2.Text);


                NumberLibrary.Calculater obj = new NumberLibrary.Calculater();
                int total = obj.GetSubstract(n1, n2);
                lbl_sub.Text = total.ToString();


            }
        }
    }
}