﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_assignment1
{
    class Manager
    {


        public void getEmployee(IManagerEmp IM)

        {
            int id = IM.getemployeeId();
            int exp = IM.getEmployeeExp();
            string project = IM.getEmployeeProjectDetails();
            Console.WriteLine("ID : " + id + " " + "EXP : " + exp + " " + "Project : " + project);

        }
    }
}
