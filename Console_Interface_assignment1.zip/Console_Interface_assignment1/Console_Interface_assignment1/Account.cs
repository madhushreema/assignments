﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_assignment1
{
    class Account
    {

        public void getEmployee(IAccountEmp IA)
        {
            int sal = IA.getEmployeeSalary();
            int accno = IA.getEmployeeAccountNo();
            int id = IA.getEmployeeId();
            Console.WriteLine("Salary : "+" " +sal + " " + "Account no : " +accno + " "+"ID : "  + id);



        }
    }
}
