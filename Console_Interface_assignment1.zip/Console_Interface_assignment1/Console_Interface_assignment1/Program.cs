﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e = new Employee(12, "Rse", 23000, "Tumkur", "dfgdfg", 34, 32425, "SBI", 34);
            Account a = new Account();
            Manager m = new Manager();
            HR hr = new HR();
            a.getEmployee(e);
            m.getEmployee(e);
            hr.getEmployee(e);


        
            Console.ReadLine();
           

        }
    }
}
