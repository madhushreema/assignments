﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_assignment1
{
    class HR
    {
        public void getEmployee(IHREmp He)
        {
          string add=  He.getEmployeeAddress();
          int sal=  He.getEmployeeSalary();
           int id= He.getEmployeeId();

            Console.WriteLine("Address : "+ " " +add + " "+"Salary :  " + sal + " "+"ID : " + id);

        }
    }
}
