﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_assignment1
{
    class Employee : IHREmp,IManagerEmp,IAccountEmp
    {
        private int EmpId;
        private string EmpName;
        private int EmpSalary;
        private String EmpAddress;
        private string ProjectDetails;
        private int EmpExp;
        private int EmpAccNo;
        private string EmpAccBankName;
        private int age;

        public Employee(int EmpId,string EmpName,int EmpSalary,string EmpAddress,string ProjectDetails,int EmpExp,int EmpAccNo,string EmpAccBankName,int age)
        {
            this .EmpId = EmpId;
            this.EmpName = EmpName;
            this.EmpSalary = EmpSalary;
            this.EmpAddress = EmpAddress;
            this.ProjectDetails = ProjectDetails;
            this.EmpExp = EmpExp;
            this.EmpAccNo = EmpAccNo;
            this.EmpAccBankName = EmpAccBankName;
            this.age = age;


        }

        public int getEmployeeSalary()
        {
            return this.EmpSalary;
        }

        public int getEmployeeAccountNo()
        {
            return this.EmpAccNo;
        }

        public int getEmployeeId()
        {
            return this.EmpId;
        }

        public int getemployeeId()
        {
            return this.EmpId;
         }

        public int getEmployeeExp()
        {
            return this.EmpExp;
                
                
                }

        public string getEmployeeProjectDetails()
        {
            return this.ProjectDetails;
        }

        public string getEmployeeAddress()
        {
            return this.EmpAddress;
        }
    }
}
