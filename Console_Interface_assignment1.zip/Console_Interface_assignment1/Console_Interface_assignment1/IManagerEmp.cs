﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_assignment1
{
    interface IManagerEmp
    {

        int getemployeeId();
        int getEmployeeExp();
        string getEmployeeProjectDetails();

    }
}
