﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for placeOrder
/// </summary>
public class placeOrder
{
    public int OrderID { get; set; }
     public  string CustomerEmailID { get; set; }
    public int ProductID {  get; set; }
    public int ProductPrice { get; set; }
    public int ProductQty { get; set; }
    public string City { get; set; }
    public string PaymentType { get; set; }
    public string Address { get; set; }


    }
