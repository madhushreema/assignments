﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment_Ovr
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter CustomerName :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Item Qty :");
            int qty = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Item Price :");
            int price = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Enter Type:");
            string Type = Console.ReadLine();

            Order o = null;
            if(Type=="Order")
            {
                o= new Order(name, qty, price);

            }
            else if(Type=="Overseas")
            {


                o = new Order_Overseas(name, qty, price);
            }
            if(o != null)
            {

                int val = o.GetOrderValue();
                Console.WriteLine(val);
                Console.ReadLine();




            }
            //Order o = new Order(name, qty, price);
            //int a = o.POrderId;
            //string b = o.PcustomerName;
            //int c = o.PItemQty;
            //int d = o.PPrice;
            //int e = o.GetOrderValue();


            //Console.WriteLine(a + " " + b + " " + c +" " + d);
            //Console.WriteLine("Ammount :" + e);






            Console.ReadLine();
        }

        
    }
}
