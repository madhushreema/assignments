﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Assignment_Ovr
{
    class Order
    {
        private int  OrderId;

        private string CustomerName;
        private int ItemQty;
        private int ItemPrice;
          
        public int POrderId
        {
            get { return this.OrderId; }
        }
        public string PcustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int PItemQty
        {
            get
            {
                return this.ItemQty;
            }
        }
        public int PPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        private static int count=1000;
        public Order(string  CustomerName,int ItemQty,int ItemPrice)
        {
            Order.count++;
            this.OrderId = Order.count;
            this.CustomerName = CustomerName;
            this.ItemQty = ItemQty;
            this.ItemPrice = ItemPrice;

        }
        public virtual int GetOrderValue()
        {
            int ord = this.ItemPrice * this.ItemQty;
            return ord;
        }



    }
}
