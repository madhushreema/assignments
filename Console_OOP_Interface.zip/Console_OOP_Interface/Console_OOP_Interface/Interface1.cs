﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Interfac { 
    interface Interface1
    {

        string GetAddress();
    }
}
