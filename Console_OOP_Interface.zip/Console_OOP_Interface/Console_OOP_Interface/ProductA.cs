﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Interface
{
    class ProductA : IProductTransport
    {
        public string GetAddress()
        {
            return "Hydrabad";
        }
    

    private int Pid;
        private string Pname;
        public ProductA(int Pid,string Pname)
        {
            this.Pid = Pid;
            this.Pname = Pname;

        }
        public int GetPrice()
        {
            return 200000;
        }
        public string GetDetails()
        {
            return this.Pid + " " + this.Pname;
        }
    }
}
