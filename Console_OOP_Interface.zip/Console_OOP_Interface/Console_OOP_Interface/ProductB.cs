﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Interface
{
    class ProductB : IProductTransport
    {

        private int Pid;
        private string Pname;

     public    ProductB(int Pid ,string Pname)
        {
            this.Pid = Pid;
            this.Pname = Pname;
        }
        public int GetPrice()
        {
            return 20000;
        }
        public string GetDetails()
        {
            return this.Pid + " " + this.Pname;
        }
        public void start() { }
        public void stop() { }

        public string GetAddress()
        {
           return "Banglore";
        }
    }
}
