﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Interface
{
    class Program
    {
        static void Main(string[] args)
        {

            //ProductA obj1 = new ProductA(10001, "DotNet");
            //ProductB obj2 = new ProductB(2000, "OnePlus");
            //Transport t = new Transport();
            //t.send(obj1);
            //t.send(obj2);

            string s1 = "a";
            char[] c = { 'a' };
            object obj = new string(c);
            Console.WriteLine(s1 == obj);
            Console.WriteLine(s1.Equals(obj));

            Console.ReadLine();

        }
    }
}
