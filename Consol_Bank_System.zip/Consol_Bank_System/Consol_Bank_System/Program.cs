﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consol_Bank_System
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter Deatils");
            Console.WriteLine("Acc_ID:");
            int acc = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("customer Name:");
            String name = Console.ReadLine();
            Console.WriteLine("Address:");
            Console.ReadLine();
            Console.WriteLine("Type of acc");
            Console.ReadLine();
            Console.WriteLine("Balance: ");
            int Bal = Convert.ToInt32(Console.ReadLine());

            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter 1. Deposite 2.withdraw 3.Check Balance 4. exit");
                int op = Convert.ToInt32(Console.ReadLine());

                //Console.WriteLine(flag);
                

                switch (op)
                {
                    case 1:
                        Console.WriteLine("Enter ammount to be Deposite");

                        int dep = Convert.ToInt32(Console.ReadLine());

                        if (dep < 500)
                        {


                            Console.WriteLine("Minimun Ammount should 500");
                            break;

                        }
                        else
                        {
                            Bal = Bal + dep;

                            Console.WriteLine("Balance  is" + Bal);

                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter Withdraw ammount");


                        int wit = Convert.ToInt32(Console.ReadLine());


                        if (wit < 500)
                        {
                            Console.WriteLine("Entred wrong ammount min 5000");



                        }
                        else
                        {



                            Bal = Bal - wit;
                            Console.WriteLine("Ofter withdraw balance is" + Bal);


                        }
                        break;



                    case 3:
                        Console.WriteLine("Balance is" + Bal);
                        break;
                    case 4:
                        flag = false;
                        
                        break;










                        



                }

              //  Console.ReadLine();
            }
        }
    }

    }

   

