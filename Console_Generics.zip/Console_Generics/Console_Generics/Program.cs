﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generics
{
    class Program
    {
        static void Main(string[] args)
        {

            List<int> marks = new List<int>();
            marks.Add(1000);
            marks.Add(2000);
            int m = marks[0];
            foreach(int nm in marks)
            {
                Console.WriteLine(nm);   
            }
            List<string> names = new List<string>();
            names.Add("A");
            names.Add("B");
            foreach(string  n in names)
            {
                Console.WriteLine(n);
            }
            Dictionary<int, string> namesWithKey = new Dictionary<int, string>();
            namesWithKey.Add(1001, "ABC");
            namesWithKey.Add(1002, "fgh");
           
            //Test t = new Test();
            //int x = t.GetDetails<int>(1000);
            //string str = t.GetDetails<string>("GAGAN");

            //Console.WriteLine(x);
            //Console.WriteLine(str);
            Console.ReadLine();
        }
    }
}
