﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2_CallbyVal_CallbyRef
{
    class Program
    {
        static void Main(string[] args)
        {



            XYZ obj1 = new XYZ();
            obj1.Call();
            obj1.GetData();

            //int[] marks = new int[3];
            //marks[0] = 10;
            //marks[1] = 20;
            //marks[2] = 30;

            Test obj = new Test();

            obj.CallArray(12,23,45,56);

            int OrderAmt = obj.GetOrderValue(ItemQty:3,itemPrice:2000);
            Console.WriteLine(OrderAmt);
            int x = 100;
            obj.Call(ref x);
            Console.WriteLine(x);
            Console.ReadLine();


        }
    }
}
