﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2_CallbyVal_CallbyRef
{
  partial  class XYZ
    {

        public void Call()
        {

        }
    }
}
