﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2_CallbyVal_CallbyRef
{
    class Test
    {

        public void Call(ref int Amt)
        {
            //Console.WriteLine(Amt);
            Amt = 1000;
        }
        public void CallArray(params int [] marks)
        {
            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }
        }
        public int GetOrderValue(int itemPrice , int ItemQty=1)
        {
            return ItemQty * itemPrice;
        }
    }
}
