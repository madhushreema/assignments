﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Account ID : ");
            int AccID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Entre Customer Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Balance :");
            int Balance = Convert.ToInt32(Console.ReadLine());


            Account obj = new Account(AccID, name, Balance);

            int NewBalance = obj.GetBalance();

            Console.WriteLine("Account Balance :" + NewBalance);

            Console.WriteLine("Enter An Ammount To Withdraw");
            int Amt = Convert.ToInt32(Console.ReadLine());

            obj.Withdraw(Amt);

            NewBalance = obj.GetBalance();
            Console.WriteLine("Enter the ammount to Deposite:");
            Amt = Convert.ToInt32(Console.ReadLine());
            obj.Deposite(Amt);

            NewBalance = obj.GetBalance();
            Console.WriteLine("Account Balance :" + NewBalance);


            //Console.WriteLine("Entrer CustomerID :");
            //int id = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Enter Customername :");
            //string name = Console.ReadLine();
            //Console.WriteLine("Enter CustomerCity :");
            //string city = Console.ReadLine();
            //Customer obj = new Customer(id, name, city);


            //string details = obj.GetDetails();
            //Console.WriteLine(details);
            Console.ReadLine();
        }
    }
}
