﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Account
    {

        private int AccountID;

        private string CustomerName;
        private int AccountBalance;



        public Account(int AccountID, string CustomerName , int AccountBalance) :this()
        {


            this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;

            Console.WriteLine("Constructor called parameters");
        }

        public Account()
            {


            Console.WriteLine("Constructor Called");
            }

        public void Withdraw(int Amt)
        {
            this.AccountBalance = this.AccountBalance - Amt;
        }

        public void Deposite(int Amt)
            {
            this.AccountBalance = this.AccountBalance + Amt;
        }
        public int  GetBalance()
        {

            return this.AccountBalance;
        }
        public string GetName()
        {
            return this.CustomerName;
        }


    }
}
