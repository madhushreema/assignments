﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_Day1_Basic2
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] nums = new int[5];
          /*  nums[0] = 10;
            nums[1] = 11;
            nums[2] = 12;
            nums[3] = 13;
            nums[4] = 14;

            for(int c=0;c<nums.Length;c++)
            {
                Console.WriteLine(nums[c]);
            }
            */
            foreach(int n in nums)
            {
                Console.WriteLine(n);
            }
          /*  int x = 0;
            while(x<10)
            {
                Console.WriteLine(x);
                x++;
            }
            for(int c=0;c<10;c++)
            {
                Console.WriteLine(c);


            
            }
            int opt = 3;
            switch(opt)
            {

                case 1:
                    Console.WriteLine("ONE");
                    break;
                case 2:
                    Console.WriteLine("TWO");
                    break;
                case 3:
                    Console.WriteLine("TREE");
                    break;
                default:
                    Console.WriteLine("Wrong Option");
                    break;
            }





            Console.WriteLine("Enter Item Name:");
            string itemname = Console.ReadLine();
            Console.WriteLine("Enter quantity:");
            int qty = Convert.ToInt32(Console.ReadLine());
            if(qty<1)
            {
                Console.WriteLine("Invallid quantity");

            }
            else
            {
                Console.WriteLine("order placed");
            }*/
            Console.ReadLine();


        }
    }
}
