﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class Home : System.Web.UI.Page
{
    //protected override void OnPreInit(EventArgs e)
    //{
    //    this.MasterPageFile = "~PathFrontBGL.master";
    //}
    protected void Page_Load(object sender, EventArgs e)
    {
        //this.MasterPageFile = "~PathFrontmaster.master";
    }

   

    protected void b1_Click(object sender, EventArgs e)
    {
        Label l = this.Master.FindControl("l1") as Label;
        l.Text = "Hello from Content Page";
    }
}