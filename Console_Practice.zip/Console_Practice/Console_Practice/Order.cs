﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice
{
    class Order
    {
        public int OrderId;
        public string CustomerName;
        public string ItemName;
        public int ItemPrice;
        public int ItemQty;


        public int POrderId
        {
            get
            {
                return this.OrderId;
            }

        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PItemName
        {
            get
            {
                return this.ItemName;
            }
        }

        public int  PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public int PItemQty
        {
            get
            {
                return this.ItemPrice;
            }
        }
        private static int count = 1000;
        public Order(String CustomerName,string ItemName, int ItemPrice,int ItemQty)
        {
            Order.count++;
            this.OrderId = Order.count;
           // this.OrderId = OrderId;
            this.CustomerName = CustomerName;
            this.ItemPrice = ItemPrice;
            this.ItemQty = ItemQty;
        }





        public int amt( )
        {
            int amt = this.ItemQty * this.ItemPrice;
            return amt;

        }
    }
}
