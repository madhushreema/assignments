﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter Custmor Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter ItemName:");
            String iname = Console.ReadLine();
            Console.WriteLine("Enter Item price :");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Item Qty :");
            int qty = Convert.ToInt32(Console.ReadLine());


            Order o = new Order(name, iname, price, qty);
            int a = o.POrderId;
            string b = o.PCustomerName;
            string c = o.PItemName;
            int d = o.PItemPrice;
            int e = o.PItemQty;
            Console.WriteLine(a + " " + b + " " + c + " " + d + " " + e);

            int k = o.amt();
            Console.WriteLine("Ammonut=" + k);
            Console.ReadLine();
















        }
    }
}
