﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_Threads
{
    public partial class frm_async : Form
    {
        public delegate int delthread(int n1, int n2);

        public int GetSum(int n1, int n2)
        {
            Thread.Sleep(5000);
            return n1 + n2;
        }


        public delegate void del();
        public void callback(IAsyncResult res)
        {
            int returndata = d.EndInvoke(res);
            //MessageBox.Show("GetSum called:"+"  " +res.AsyncState+" : " +returndata);
            //  int returndata = d.EndInvoke(res);

            //  MessageBox.Show("Return value:"+)

            //lbl_msg.Text += res.AsyncState + " :" + returndata;

            del obj = new del(() =>
              {
                  // lbl_msg.Text += res.AsyncState + " :" + returndata;
                  lst_msg.Items.Add(res.AsyncState + " :" + returndata);
              });
            this.BeginInvoke(obj);


                 }









        public frm_async()
        {
            InitializeComponent();
        }
        delthread d;
        private void btn_t1_Click(object sender, EventArgs e)
        {

            if(d==null)
            {
                 d = new delthread(this.GetSum);

            }
            int n1 = Convert.ToInt32(txt_n1.Text);
            int n2 = Convert.ToInt32(txt_n2.Text);

            string str = n1 + " + " + n2;
            

            d.BeginInvoke(n1, n2, callback, str);
            //d.BeginInvoke(2, 10, callback, "2000");

        }

        
    }
}
