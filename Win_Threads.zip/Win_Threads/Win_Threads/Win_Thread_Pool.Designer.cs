﻿namespace Win_Threads
{
    partial class Win_Thread_Pool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_pool = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_pool
            // 
            this.btn_pool.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pool.Location = new System.Drawing.Point(149, 119);
            this.btn_pool.Name = "btn_pool";
            this.btn_pool.Size = new System.Drawing.Size(234, 66);
            this.btn_pool.TabIndex = 0;
            this.btn_pool.Text = "TreadPool";
            this.btn_pool.UseVisualStyleBackColor = true;
            this.btn_pool.Click += new System.EventHandler(this.btn_pool_Click);
            // 
            // Win_Thread_Pool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 261);
            this.Controls.Add(this.btn_pool);
            this.Name = "Win_Thread_Pool";
            this.Text = "Win_Thread_Pool";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_pool;
    }
}