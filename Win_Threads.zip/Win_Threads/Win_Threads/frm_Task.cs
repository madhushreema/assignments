﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Threads
{
    public partial class frm_Task : Form
    {
        public frm_Task()
        {
            InitializeComponent();
        }

        private void bt_New_Task_Click(object sender, EventArgs e)
        {
            Task t1 = Task.Run(() =>
              {
                  MessageBox.Show("Task one:");


              });
            Task t2 = Task.Run(() =>
              {
                  MessageBox.Show("Task  two:");
              });
        }

        private async void btn_task2_Click(object sender, EventArgs e)
        {
            TestClass obj = new TestClass();
           var t= obj.AddNumberAsync(10, 20);
            MessageBox.Show("Some othr task");
            int x = await t;
            MessageBox.Show("Return data: " + x);
        }
    }
}
