﻿namespace Win_Threads
{
    partial class frm_locking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_n1 = new System.Windows.Forms.Label();
            this.lbl_n2 = new System.Windows.Forms.Label();
            this.txt_n1 = new System.Windows.Forms.TextBox();
            this.txt_n2 = new System.Windows.Forms.TextBox();
            this.btn_t1 = new System.Windows.Forms.Button();
            this.btn_t2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_n1
            // 
            this.lbl_n1.AutoSize = true;
            this.lbl_n1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_n1.Location = new System.Drawing.Point(129, 61);
            this.lbl_n1.Name = "lbl_n1";
            this.lbl_n1.Size = new System.Drawing.Size(70, 17);
            this.lbl_n1.TabIndex = 0;
            this.lbl_n1.Text = "Number1:";
            // 
            // lbl_n2
            // 
            this.lbl_n2.AutoSize = true;
            this.lbl_n2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_n2.Location = new System.Drawing.Point(129, 133);
            this.lbl_n2.Name = "lbl_n2";
            this.lbl_n2.Size = new System.Drawing.Size(70, 17);
            this.lbl_n2.TabIndex = 1;
            this.lbl_n2.Text = "Number2:";
            // 
            // txt_n1
            // 
            this.txt_n1.Location = new System.Drawing.Point(255, 60);
            this.txt_n1.Name = "txt_n1";
            this.txt_n1.Size = new System.Drawing.Size(100, 20);
            this.txt_n1.TabIndex = 2;
            // 
            // txt_n2
            // 
            this.txt_n2.Location = new System.Drawing.Point(255, 130);
            this.txt_n2.Name = "txt_n2";
            this.txt_n2.Size = new System.Drawing.Size(100, 20);
            this.txt_n2.TabIndex = 3;
            // 
            // btn_t1
            // 
            this.btn_t1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_t1.Location = new System.Drawing.Point(132, 210);
            this.btn_t1.Name = "btn_t1";
            this.btn_t1.Size = new System.Drawing.Size(96, 39);
            this.btn_t1.TabIndex = 4;
            this.btn_t1.Text = "Thread1";
            this.btn_t1.UseVisualStyleBackColor = true;
            this.btn_t1.Click += new System.EventHandler(this.btn_t1_Click);
            // 
            // btn_t2
            // 
            this.btn_t2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_t2.Location = new System.Drawing.Point(280, 210);
            this.btn_t2.Name = "btn_t2";
            this.btn_t2.Size = new System.Drawing.Size(75, 39);
            this.btn_t2.TabIndex = 5;
            this.btn_t2.Text = "Thread2";
            this.btn_t2.UseVisualStyleBackColor = true;
            this.btn_t2.Click += new System.EventHandler(this.btn_t2_Click);
            // 
            // frm_locking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 261);
            this.Controls.Add(this.btn_t2);
            this.Controls.Add(this.btn_t1);
            this.Controls.Add(this.txt_n2);
            this.Controls.Add(this.txt_n1);
            this.Controls.Add(this.lbl_n2);
            this.Controls.Add(this.lbl_n1);
            this.Name = "frm_locking";
            this.Text = "frm_locking";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_n1;
        private System.Windows.Forms.Label lbl_n2;
        private System.Windows.Forms.TextBox txt_n1;
        private System.Windows.Forms.TextBox txt_n2;
        private System.Windows.Forms.Button btn_t1;
        private System.Windows.Forms.Button btn_t2;
    }
}