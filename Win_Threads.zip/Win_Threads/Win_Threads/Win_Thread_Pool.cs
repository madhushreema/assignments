﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace Win_Threads
{
    public partial class Win_Thread_Pool : Form
    {
        public void call(object obj)
        {
            int id = Thread.CurrentThread.ManagedThreadId;
            MessageBox.Show("Thead ID:" + id + ", Loop No :" + obj);

        }
        public Win_Thread_Pool()
        {
            InitializeComponent();
        }

        private void btn_pool_Click(object sender, EventArgs e)
        {
            ThreadPool.SetMaxThreads(10, 1000);//10:worker Thread 100:Port thread
            ThreadPool.SetMinThreads(5, 1000);
            int count = 0;
            while(count<20)
            {
                ThreadPool.QueueUserWorkItem(call, count);//Que of the word which call thread
                count++;
            }

        }
    }
}
