﻿namespace Win_Threads
{
    partial class frm_Task
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_New_Task = new System.Windows.Forms.Button();
            this.btn_task2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_New_Task
            // 
            this.bt_New_Task.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_New_Task.Location = new System.Drawing.Point(75, 100);
            this.bt_New_Task.Name = "bt_New_Task";
            this.bt_New_Task.Size = new System.Drawing.Size(95, 70);
            this.bt_New_Task.TabIndex = 0;
            this.bt_New_Task.Text = "New_Task";
            this.bt_New_Task.UseVisualStyleBackColor = true;
            this.bt_New_Task.Click += new System.EventHandler(this.bt_New_Task_Click);
            // 
            // btn_task2
            // 
            this.btn_task2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_task2.Location = new System.Drawing.Point(267, 100);
            this.btn_task2.Name = "btn_task2";
            this.btn_task2.Size = new System.Drawing.Size(114, 70);
            this.btn_task2.TabIndex = 1;
            this.btn_task2.Text = "New_Task 2";
            this.btn_task2.UseVisualStyleBackColor = true;
            this.btn_task2.Click += new System.EventHandler(this.btn_task2_Click);
            // 
            // frm_Task
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 261);
            this.Controls.Add(this.btn_task2);
            this.Controls.Add(this.bt_New_Task);
            this.Name = "frm_Task";
            this.Text = "frm_Task";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_New_Task;
        private System.Windows.Forms.Button btn_task2;
    }
}