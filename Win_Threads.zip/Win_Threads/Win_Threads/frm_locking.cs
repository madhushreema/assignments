﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_Threads
{
    public partial class frm_locking : Form
    {

        ReaderWriterLock rw = new ReaderWriterLock();

        int total;
        public void sum()
        {
            //if (Monitor.TryEnter(this,3000))
            //{
                //Monitor.Enter(this);
                // lock (this)
                //{
                int n1 = Convert.ToInt32(txt_n1.Text);
                int n2 = Convert.ToInt32(txt_n2.Text);
                rw.AcquireWriterLock(Timeout.Infinite);
                total = n1 + n2;
                Thread.Sleep(15000);
                MessageBox.Show("Total: " + total);
            //}
            //  Monitor.Exit(this);
            //}
            //else
            //{
            //    MessageBox.Show("Executing onother Task:");
            //}
            rw.ReleaseLock();
        }
        public void sum2()
        {
            //if (Monitor.TryEnter(this,3000))
            //{
            //Monitor.Enter(this);
            // lock (this)
            //{
            int n1 = Convert.ToInt32(txt_n1.Text);
            int n2 = Convert.ToInt32(txt_n2.Text);
            rw.AcquireWriterLock(Timeout.Infinite);
            total = n1 + n2;
            Thread.Sleep(15000);
            MessageBox.Show("Total: " + total);
            //}
            //  Monitor.Exit(this);
            //}
            //else
            //{
            //    MessageBox.Show("Executing onother Task:");
            //}
            rw.ReleaseLock();
        }



        public frm_locking()
        {
            InitializeComponent();
        }

        private void btn_t1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(this.sum);
            th1.Start();
        }

        private void btn_t2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(this.sum2);
            th2.Start();
        }
    }
}
