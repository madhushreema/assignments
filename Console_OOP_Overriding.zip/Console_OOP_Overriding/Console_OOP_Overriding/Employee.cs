﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Employee
    {

        private int  EmployeeId;
        private string EmpName;
        private int EmpSalary;

        public Employee(int EmployeeId, string EmpName, int EmpSalary)
        {

            this.EmployeeId = EmployeeId;
            this.EmpName = EmpName;
            this.EmpSalary = EmpSalary;




        }


        public int PEmplyeeId
        {
            get
            {
                return EmployeeId;
            }
        }
        public string PEmpName
        { get { return EmpName; } }
        public int PEmpSalry
        { get { return EmpSalary; } }



        public string GetWork()
        {
            return "Developing .Net App";        }


        public virtual int GetSalary(int Days)
        {
            int Bonus = 2000;
            int TDS = 1000;
            int Salary = (this.EmpSalary / 30 * Days) + Bonus - TDS;
            return Salary;



        }

         
    }



}
