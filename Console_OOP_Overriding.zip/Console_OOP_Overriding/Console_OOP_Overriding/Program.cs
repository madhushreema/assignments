﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter EmpId: ");
            int Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name:");
            String name = Console.ReadLine();
            Console.WriteLine("Enter Salry :");
            int salary = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Engter type of Emploppyee: ");
            String Type = Console.ReadLine();
             Employee obj = null;
            if(Type=="Employee")
            {

                obj = new Employee(Id, name, salary);
            }
            else if(Type=="Contract")
            {

                obj = new Employee_Contract(Id, name, salary);
            }
            else if(Type=="Trainee")
            {

                obj = new Employee_Trainee(Id, name, salary); 

            }
            if (obj != null)
            {
                
                string work = obj.GetWork();
                obj.
                Console.WriteLine(work);

                Console.WriteLine("Enter No.Of. Days");
                int d = Convert.ToInt32(Console.ReadLine());
                int CurrentSalary = obj.GetSalary(d);
                Console.WriteLine("Salry :" + CurrentSalary);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Entred Wrong Type");
            }


        }
    }
}
