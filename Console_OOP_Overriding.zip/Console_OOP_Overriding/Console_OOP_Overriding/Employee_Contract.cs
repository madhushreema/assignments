﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Employee_Contract : Employee 
    {
        public Employee_Contract(int EmpId,string EmpName ,int EmpSalary)
            :base(EmpId,EmpName,EmpSalary)
        {



        }
        public override int GetSalary(int Days)
        {
            int to = this.PEmpSalry / 30 * Days;
            return to;
        }



    }
}
