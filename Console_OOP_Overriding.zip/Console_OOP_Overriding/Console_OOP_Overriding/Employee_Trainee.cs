﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Employee_Trainee :Employee 
    {
        public Employee_Trainee(int EmpId,string EmpName, int EmpSalary )
            :base(EmpId,EmpName,EmpSalary)
        {


        }


        public override int GetSalary(int Days)
        {
            int to = (this.PEmpSalry / 30 * Days)-5000;
            return to;
        }
    }
}
