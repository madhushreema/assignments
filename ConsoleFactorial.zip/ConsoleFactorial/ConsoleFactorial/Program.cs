﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleFactorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            int fact = 1;
            Console.WriteLine("Enter no for factorial:");
            int n = Convert.ToInt32(Console.ReadLine());
            
            
                for (i = 1;i<=n;i++)
                {
                    fact= fact * i;
                }
                Console.WriteLine("Factrorial of given number is:"+ fact);
            Console.ReadLine();
        }
           
           
        }
        
    }

