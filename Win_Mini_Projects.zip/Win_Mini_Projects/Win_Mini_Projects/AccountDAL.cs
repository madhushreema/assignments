﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//Add
using System.Configuration;//DLL config
using System.Data;//Addd

namespace Win_Mini_Projects
{
    class AccountDAL
    {
        SqlConnection con = new SqlConnection

            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddAccount(Account ac)
        {
            try
            {
                SqlCommand com_ac_insert = new SqlCommand
                    ("proc_addAccount", con);

                com_ac_insert.Parameters.AddWithValue("@CustomerID", ac.CustomerID);
                com_ac_insert.Parameters.AddWithValue("@CustomerBalance", ac.AccountBalance);

                com_ac_insert.Parameters.AddWithValue("@type", ac.AccountType);

                com_ac_insert.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_ac_insert.Parameters.Add(retdata);
                con.Open();
                com_ac_insert.ExecuteNonQuery();
                SqlCommand com_id = new SqlCommand("select @@identity", con);
                int ID = Convert.ToInt32(com_id.ExecuteScalar());
                con.Close();
                return ID;
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        public List<Account> ShowAccount(int ID)
        {
            try
            {
                SqlCommand com_showaccount = new SqlCommand("proc_showAccount", con);
                com_showaccount.Parameters.AddWithValue("@id", ID);
                com_showaccount.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_showaccount.ExecuteReader();
                List<Account> acclist = new List<Account>();
                while (dr.Read())
                {
                    Account obj = new Account();
                    obj.AccountID = dr.GetInt32(0);
                    obj.CustomerID = dr.GetInt32(1);
                    obj.AccountBalance = dr.GetInt32(2);
                    obj.AccountType = dr.GetString(3);
                    obj.AccountOpenDate = dr.GetDateTime(4);
                    acclist.Add(obj);

                }
                con.Close();
                return acclist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }



            }
        }


        public List<int> ShowAccount1(int ID)
        {
            try
            {
                SqlCommand com_showaccount = new SqlCommand("proc_showAccount", con);
                com_showaccount.Parameters.AddWithValue("@id", ID);
                com_showaccount.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_showaccount.ExecuteReader();
                List<int> acclist = new List<int>();
                while (dr.Read())
                {

                    acclist.Add(dr.GetInt32(0));

                }
                con.Close();
                return acclist;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


            }





        }

    }
}
    
