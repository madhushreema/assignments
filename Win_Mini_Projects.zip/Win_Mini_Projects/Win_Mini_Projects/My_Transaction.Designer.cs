﻿namespace Win_Mini_Projects
{
    partial class My_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gd_show = new System.Windows.Forms.DataGridView();
            this.btn_show = new System.Windows.Forms.Button();
            this.lbl_trasactionid = new System.Windows.Forms.Label();
            this.cmb_aid = new System.Windows.Forms.ComboBox();
            this.btn_back = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gd_show)).BeginInit();
            this.SuspendLayout();
            // 
            // gd_show
            // 
            this.gd_show.BackgroundColor = System.Drawing.SystemColors.Highlight;
            this.gd_show.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gd_show.Location = new System.Drawing.Point(124, 180);
            this.gd_show.Name = "gd_show";
            this.gd_show.Size = new System.Drawing.Size(601, 203);
            this.gd_show.TabIndex = 7;
            // 
            // btn_show
            // 
            this.btn_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_show.Location = new System.Drawing.Point(288, 109);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(100, 31);
            this.btn_show.TabIndex = 6;
            this.btn_show.Text = "Show";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // lbl_trasactionid
            // 
            this.lbl_trasactionid.AutoSize = true;
            this.lbl_trasactionid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_trasactionid.Location = new System.Drawing.Point(75, 28);
            this.lbl_trasactionid.Name = "lbl_trasactionid";
            this.lbl_trasactionid.Size = new System.Drawing.Size(130, 17);
            this.lbl_trasactionid.TabIndex = 4;
            this.lbl_trasactionid.Text = "Enter AccountID:";
            // 
            // cmb_aid
            // 
            this.cmb_aid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_aid.FormattingEnabled = true;
            this.cmb_aid.Location = new System.Drawing.Point(288, 27);
            this.cmb_aid.Name = "cmb_aid";
            this.cmb_aid.Size = new System.Drawing.Size(121, 21);
            this.cmb_aid.TabIndex = 8;
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(473, 77);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(64, 23);
            this.btn_back.TabIndex = 15;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // My_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(801, 411);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.cmb_aid);
            this.Controls.Add(this.gd_show);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.lbl_trasactionid);
            this.Name = "My_Transaction";
            this.Text = "My_Transaction";
            this.Load += new System.EventHandler(this.My_Transaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gd_show)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gd_show;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.Label lbl_trasactionid;
        private System.Windows.Forms.ComboBox cmb_aid;
        private System.Windows.Forms.Button btn_back;
    }
}