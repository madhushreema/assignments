﻿namespace Win_Mini_Projects
{
    partial class My_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_myaccount = new System.Windows.Forms.Label();
            this.btn_show = new System.Windows.Forms.Button();
            this.gd_show = new System.Windows.Forms.DataGridView();
            this.txt_aid = new System.Windows.Forms.TextBox();
            this.btn_back = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gd_show)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_myaccount
            // 
            this.lbl_myaccount.AutoSize = true;
            this.lbl_myaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_myaccount.Location = new System.Drawing.Point(26, 46);
            this.lbl_myaccount.Name = "lbl_myaccount";
            this.lbl_myaccount.Size = new System.Drawing.Size(140, 17);
            this.lbl_myaccount.TabIndex = 0;
            this.lbl_myaccount.Text = "Enter CustomerID:";
            // 
            // btn_show
            // 
            this.btn_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_show.Location = new System.Drawing.Point(239, 127);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(100, 31);
            this.btn_show.TabIndex = 2;
            this.btn_show.Text = "Show";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // gd_show
            // 
            this.gd_show.BackgroundColor = System.Drawing.SystemColors.Highlight;
            this.gd_show.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gd_show.Location = new System.Drawing.Point(75, 198);
            this.gd_show.Name = "gd_show";
            this.gd_show.Size = new System.Drawing.Size(601, 203);
            this.gd_show.TabIndex = 3;
            // 
            // txt_aid
            // 
            this.txt_aid.Location = new System.Drawing.Point(239, 46);
            this.txt_aid.Name = "txt_aid";
            this.txt_aid.Size = new System.Drawing.Size(100, 20);
            this.txt_aid.TabIndex = 1;
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(425, 93);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(64, 23);
            this.btn_back.TabIndex = 15;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // My_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(841, 413);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.gd_show);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.txt_aid);
            this.Controls.Add(this.lbl_myaccount);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "My_Account";
            this.Text = "My_Account";
            this.Load += new System.EventHandler(this.My_Account_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gd_show)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_myaccount;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView gd_show;
        private System.Windows.Forms.TextBox txt_aid;
        private System.Windows.Forms.Button btn_back;
    }
}