﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Mini_Projects
{
    public partial class My_Transaction : Form
    {
        public My_Transaction()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {

            try
            {
                TransactionDAL dal = new TransactionDAL();
                int id = Convert.ToInt32(cmb_aid.Text);
                List<Transaction> list = dal.ShowTrasaction(id);
                gd_show.DataSource = list;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
    }

        private void My_Transaction_Load(object sender, EventArgs e)
        {try
            {
                // AccountDAL a = new AccountDAL();
                AccountDAL a = new AccountDAL();
                List<int> list = a.ShowAccount1(cid.CustomerID);
                foreach (int h in list)
                {


                    cmb_aid.Items.Add(h);
                    //  cmb_transtype.Items.Add(h);


                }
            }
            catch(Exception exe)
            {
                MessageBox.Show(exe.Message);
            }


        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            New n = new New();
            n.Show();
        }
    }
    }

