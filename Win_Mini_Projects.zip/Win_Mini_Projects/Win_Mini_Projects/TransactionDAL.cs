﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//Add
using System.Configuration;//DLL config
using System.Data;//Addd


namespace Win_Mini_Projects
{
    class TransactionDAL
    {
        SqlConnection con = new SqlConnection

            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


        public int AddTransaction(Transaction t)
        {try
            {

                SqlCommand com_tr = new SqlCommand("proc_addTrasaction", con);

                com_tr.Parameters.AddWithValue("@AccountID", t.AccountID);
                com_tr.Parameters.AddWithValue("@Ammount", t.Amount);

                com_tr.Parameters.AddWithValue("@type", t.TransactionType);
                //com_cus_insert.Parameters.AddWithValue("@date", cus.AccountOpenDate);
                //com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
                com_tr.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_tr.Parameters.Add(retdata);
                con.Open();
                com_tr.ExecuteNonQuery();
                SqlCommand com_id = new SqlCommand("select @@identity", con);
                int ID = Convert.ToInt32(com_id.ExecuteScalar());
                con.Close();
                return ID;

            }
            finally
            {
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
            }


        }

        public int cal(int id)
        {
            try
            {
                Transaction t = new Transaction();
                Account a = new Account();
                SqlCommand com_t = new SqlCommand("proc_bal1", con);
                com_t.Parameters.AddWithValue("@id", t.AccountID);

                com_t.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_t.Parameters.Add(retdata);
                con.Open();
                com_t.ExecuteNonQuery();

                int bal = Convert.ToInt32(retdata.Value);
                con.Close();
                return bal;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


        }
        public int AccountBalance(int id)
        {try
            {
                SqlCommand com_ac_bal = new SqlCommand("proc_bal1", con);
                com_ac_bal.Parameters.AddWithValue("@id", id);
                com_ac_bal.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_ac_bal.Parameters.Add(retdata);

                con.Open();
                com_ac_bal.ExecuteNonQuery();
                int bal = Convert.ToInt32(retdata.Value);

                con.Close();
                return bal;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }












        public List<Transaction> ShowTrasaction(int id)
        {
            try
            {
                SqlCommand com_cus = new SqlCommand("proc_showTransaction", con);
                com_cus.Parameters.AddWithValue("@id", id);
                com_cus.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_cus.ExecuteReader();

                List<Transaction> trlist = new List<Transaction>();
                while (dr.Read())
                {

                    Transaction obj = new Transaction();
                    obj.TransactionID = dr.GetInt32(0);
                    obj.AccountID = dr.GetInt32(1);
                    obj.Amount = dr.GetInt32(2);
                    obj.TransactionType = dr.GetString(3);
                    obj.TransDate = dr.GetDateTime(4);

                    trlist.Add(obj);

                }
                con.Close();
                return trlist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }







      




















    }
}
