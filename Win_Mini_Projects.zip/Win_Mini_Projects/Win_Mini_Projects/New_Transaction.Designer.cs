﻿namespace Win_Mini_Projects
{
    partial class New_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.btn_reset = new System.Windows.Forms.Button();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.lbl_ttype = new System.Windows.Forms.Label();
            this.lbl_aid = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.cmb_transtype = new System.Windows.Forms.ComboBox();
            this.cmb_ac = new System.Windows.Forms.ComboBox();
            this.btn_back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_amount
            // 
            this.txt_amount.Location = new System.Drawing.Point(279, 155);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(121, 20);
            this.txt_amount.TabIndex = 15;
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(261, 223);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 33);
            this.btn_reset.TabIndex = 12;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_balance.Location = new System.Drawing.Point(137, 158);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(111, 17);
            this.lbl_balance.TabIndex = 10;
            this.lbl_balance.Text = "Enter Amount:";
            // 
            // lbl_ttype
            // 
            this.lbl_ttype.AutoSize = true;
            this.lbl_ttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ttype.Location = new System.Drawing.Point(137, 115);
            this.lbl_ttype.Name = "lbl_ttype";
            this.lbl_ttype.Size = new System.Drawing.Size(140, 17);
            this.lbl_ttype.TabIndex = 9;
            this.lbl_ttype.Text = "Transaction Type:";
            // 
            // lbl_aid
            // 
            this.lbl_aid.AutoSize = true;
            this.lbl_aid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aid.Location = new System.Drawing.Point(134, 68);
            this.lbl_aid.Name = "lbl_aid";
            this.lbl_aid.Size = new System.Drawing.Size(86, 17);
            this.lbl_aid.TabIndex = 8;
            this.lbl_aid.Text = "AccountID:";
            // 
            // btn_add
            // 
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.Location = new System.Drawing.Point(379, 232);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 16;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // cmb_transtype
            // 
            this.cmb_transtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_transtype.FormattingEnabled = true;
            this.cmb_transtype.Location = new System.Drawing.Point(279, 111);
            this.cmb_transtype.Name = "cmb_transtype";
            this.cmb_transtype.Size = new System.Drawing.Size(121, 21);
            this.cmb_transtype.TabIndex = 18;
            // 
            // cmb_ac
            // 
            this.cmb_ac.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_ac.FormattingEnabled = true;
            this.cmb_ac.Location = new System.Drawing.Point(279, 59);
            this.cmb_ac.Name = "cmb_ac";
            this.cmb_ac.Size = new System.Drawing.Size(121, 21);
            this.cmb_ac.TabIndex = 19;
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(318, 281);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(64, 23);
            this.btn_back.TabIndex = 20;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // New_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(681, 316);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.cmb_ac);
            this.Controls.Add(this.cmb_transtype);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_amount);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.lbl_balance);
            this.Controls.Add(this.lbl_ttype);
            this.Controls.Add(this.lbl_aid);
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Name = "New_Transaction";
            this.Text = "New_Transaction";
            this.Load += new System.EventHandler(this.New_Transaction_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label lbl_ttype;
        private System.Windows.Forms.Label lbl_aid;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.ComboBox cmb_transtype;
        private System.Windows.Forms.ComboBox cmb_ac;
        private System.Windows.Forms.Button btn_back;
    }
}