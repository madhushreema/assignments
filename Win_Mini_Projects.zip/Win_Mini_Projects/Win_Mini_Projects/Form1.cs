﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Mini_Projects
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            
            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("Enter Login ID");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");

            }
            else
            {
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Login(Convert.ToInt32(txt_id.Text), txt_password.Text);

                if (status)
                {
                    cid.CustomerID = Convert.ToInt32(txt_id.Text);
                    New f = new New();
                    f.Show();
                }
                else
                {
                    MessageBox.Show("invalid");
                }
            }
        }
        private void btn_new_Click(object sender, EventArgs e)
        {
            New_Registration f = new New_Registration();
            f.Show();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_id.Text = string.Empty;
            txt_password.Text= string.Empty;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
