﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Mini_Projects
{
    public partial class My_Account : Form
    {
        public My_Account()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            try
            {
                AccountDAL dal = new AccountDAL();
                int id = Convert.ToInt32(txt_aid.Text);
                List<Account> list = dal.ShowAccount(id);
                gd_show.DataSource = list;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void My_Account_Load(object sender, EventArgs e)
        {
            try
            {
                txt_aid.Text = cid.CustomerID.ToString();
                txt_aid.Enabled = false;

            }
            catch(Exception exe)
            {
                MessageBox.Show(exe.Message);
            }

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            New n = new New();
            n.Show();
        }
    }
}
