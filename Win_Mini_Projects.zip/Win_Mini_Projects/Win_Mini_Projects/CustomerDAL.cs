﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//Add
using System.Configuration;//DLL config
using System.Data;//Addd


namespace Win_Mini_Projects
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection

            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


        public int AddCustomer(Customer cus)
        {
            try
            {
                SqlCommand com_cus_insert = new SqlCommand
                    ("proc_addCustomer", con);

                com_cus_insert.Parameters.AddWithValue("@name", cus.CustomerName);
                com_cus_insert.Parameters.AddWithValue("@email", cus.CustomerEmail);

                com_cus_insert.Parameters.AddWithValue("@phone", cus.CustomerPhone);
                com_cus_insert.Parameters.AddWithValue("@gender", cus.CustomerGender);
                com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
                com_cus_insert.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_cus_insert.Parameters.Add(retdata);
                con.Open();
                com_cus_insert.ExecuteNonQuery();
                SqlCommand com_id = new SqlCommand("select @@identity", con);
                int ID = Convert.ToInt32(com_id.ExecuteScalar());
                con.Close();
                return ID;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        //public int AddAccount(Account cus)
        //{

        //    SqlCommand com_cus_insert = new SqlCommand
        //        ("proc_addAccount", con);

        //    com_cus_insert.Parameters.AddWithValue("@CustomerID", cus.CustomerID);
        //    com_cus_insert.Parameters.AddWithValue("@ustomerBalance", cus.AccountBalance);

        //    com_cus_insert.Parameters.AddWithValue("@type", cus.AccountType);
        //    //com_cus_insert.Parameters.AddWithValue("@date", cus.AccountOpenDate);
        //    //com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
        //    com_cus_insert.CommandType = CommandType.StoredProcedure;
        //    SqlParameter retdata = new SqlParameter();
        //    retdata.Direction = ParameterDirection.ReturnValue;
        //    com_cus_insert.Parameters.Add(retdata);
        //    con.Open();
        //    com_cus_insert.ExecuteNonQuery();
        //    SqlCommand com_id = new SqlCommand("select @@identity", con);
        //    int ID = Convert.ToInt32(com_id.ExecuteScalar());
        //    con.Close();
        //    return ID;

        //}

        public List<Customer> ShowCustomer(int id)
        {
            try
            {
                SqlCommand com_cus = new SqlCommand("proc_showA", con);
                com_cus.Parameters.AddWithValue("@id", id);
                com_cus.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_cus.ExecuteReader();

                List<Customer> cuslist = new List<Customer>();
                while (dr.Read())
                {

                    Customer obj = new Customer();
                    obj.CustomerID = dr.GetInt32(0);
                    obj.CustomerName = dr.GetString(1);
                    obj.CustomerEmail = dr.GetString(2);
                    obj.CustomerGender = dr.GetString(4);
                    obj.CustomerPhone = dr.GetString(3);
                    obj.CustomerPassword = dr.GetString(5);
                    cuslist.Add(obj);

                }
                con.Close();
                return cuslist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        //public List<Customer> ShowCustomer(int id)
        //{

        //    SqlCommand com_cus = new SqlCommand("proc_showA", con);
        //    com_cus.Parameters.AddWithValue("@id", id);
        //    com_cus.CommandType = CommandType.StoredProcedure;
        //    con.Open();
        //    SqlDataReader dr = com_cus.ExecuteReader();

        //    List<Customer> cuslist = new List<Customer>();
        //    while (dr.Read())
        //    {

        //        Customer obj = new Customer();
        //        obj.CustomerID = dr.GetInt32(0);
        //        obj.CustomerName = dr.GetString(1);
        //        obj.CustomerEmail = dr.GetString(2);
        //        obj.CustomerGender = dr.GetString(4);
        //        obj.CustomerPhone = dr.GetString(3);
        //        obj.CustomerPassword = dr.GetString(5);
        //        cuslist.Add(obj);

        //    }
        //    con.Close();
        //    return cuslist;

        //}


        public bool Login(int ID, string Password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);

                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(retdata);
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);

                if (count > 0)
                {

                    return true;
                }
                else
                { return false; }
            }
            //}
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            // }
            //catch (System.Data.SqlClient.SqlException)
            //{
            //    Console.WriteLine("Sql Error:");            

            //finally
            //{
            //    System.Windows.Forms.MessageBox.Show("Finally");
            //    if (con.State == ConnectionState.Open)
            //    {
            // con.Close();
            //}
        }
    }
}
























    































    







