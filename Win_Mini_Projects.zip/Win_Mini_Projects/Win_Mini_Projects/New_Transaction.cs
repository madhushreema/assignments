﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Mini_Projects
{
    public partial class New_Transaction : Form
    {
        public New_Transaction()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            //txt_tid.Text = string.Empty;
            cmb_transtype.Text = string.Empty;
            txt_amount.Text = string.Empty;
        }
        private void New_Transaction_Load(object sender, EventArgs e)
        {
           
        }
        private void btn_add_Click(object sender, EventArgs e)
        { 
           if(cmb_ac.Text==string.Empty)
           {
                MessageBox.Show("Enter Account ID:");
           }
            if (cmb_transtype.Text == string.Empty)
            {
                MessageBox.Show("Enter Transaction Type:");
            }
            else if (txt_amount.Text == string.Empty)
            {
                MessageBox.Show("Enter Ammount:");

            }
            else
            {
                // if()

                int id = Convert.ToInt32(cmb_ac.Text);
                string type = cmb_transtype.Text;
                int balance = Convert.ToInt32(txt_amount.Text);
                Account a = new Account();
                Transaction t = new Transaction();
                t.AccountID = id;
                t.Amount = balance;
                t.TransactionType = type;
                //  int id;//= dal.addTransaction(t);
                TransactionDAL dal = new TransactionDAL();
                int bal = dal.AccountBalance(Convert.ToInt32(cmb_ac.Text));

                if (t.TransactionType == "Deposit")
                {
                    id = dal.AddTransaction(t);
                    MessageBox.Show("Transaction ID is" + id);
                }

                else
                {

                    if (t.Amount < bal)
                    {
                        id = dal.AddTransaction(t);
                        MessageBox.Show("Transaction ID is" + id);
                    }
                    else
                    {
                        MessageBox.Show("In sufficient Balance" + bal);
                    }

                }


            }
        }

        
    
        
        




        

        

     

        private void cmb_ac_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void New_Transaction_Load_1(object sender, EventArgs e)
        {
            AccountDAL a = new AccountDAL();
            List<int> list = a.ShowAccount1(cid.CustomerID);
            foreach (int h in list)
            {


                cmb_ac.Items.Add(h);
                //  cmb_transtype.Items.Add(h);


            }
            cmb_transtype.Items.Add("withdra");
            cmb_transtype.Items.Add("Deposit");
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            New n = new New();
            n.Show();
        }
    }
}
