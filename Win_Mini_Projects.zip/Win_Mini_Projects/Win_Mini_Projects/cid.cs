﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Mini_Projects
{
    class cid
    {
        public static int CustomerID;


    }
}
