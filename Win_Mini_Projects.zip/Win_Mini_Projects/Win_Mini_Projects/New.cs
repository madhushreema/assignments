﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Mini_Projects
{
    public partial class New : Form
    {
        public New()
        {
            InitializeComponent();
        }

        private void btn_newaccount_Click(object sender, EventArgs e)
        {
            New_Account h = new New_Account();
            h.Show();
        }

        private void btn_myaccount_Click(object sender, EventArgs e)
        {
            My_Account h = new My_Account();
            h.Show();
        }

        private void btn_newtransaction_Click(object sender, EventArgs e)
        {
            New_Transaction h = new New_Transaction();
            h.Show();
        }

        private void btn_mytrasaction_Click(object sender, EventArgs e)
        {
            My_Transaction h = new My_Transaction();
            h.Show();
        }
    }
}
