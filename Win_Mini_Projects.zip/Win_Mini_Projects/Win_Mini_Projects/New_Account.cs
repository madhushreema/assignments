﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Mini_Projects
{
    public partial class New_Account : Form
    {
        public New_Account()
        {
            InitializeComponent();
        }
       

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_aid.Text = string.Empty;
            cmb_accountype.Text = string.Empty;
            txt_balance.Text = string.Empty;
        }

        private void btn_new_Click(object sender, EventArgs e)
        {

            if (txt_aid.Text == string.Empty)
            {

                MessageBox.Show("Enter AccountID");

            }
            else if (cmb_accountype.Text == string.Empty)
            {
                MessageBox.Show("Enter AccountType");
            }
            else if (txt_balance.Text == string.Empty)
            {
                MessageBox.Show("Enter Balance");
            }
            // else if(tx)
            else
            {   //txt_aid.Text=class.customerID;
                //int id = Convert.ToInt32(txt_aid.Text);
                string Atype = cmb_accountype.Text;
                int balance = Convert.ToInt32(txt_balance.Text);

                Account obj = new Account();
                //obj.AccountID = id; ;
                obj.AccountType = Atype;
                obj.AccountBalance = balance;


                AccountDAL dal = new AccountDAL();
                int id = dal.AddAccount(obj);
                MessageBox.Show("Account Added :" + id);

            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            
            if (txt_aid.Text == string.Empty)
            {
  MessageBox.Show("Enter AccountID");

            }
            else if (cmb_accountype.Text == string.Empty)
            {
                MessageBox.Show("Enter AccountType");
            }
            else if (txt_balance.Text == string.Empty)
            {
                MessageBox.Show("Enter Balance");
            }
            else
            {
                int id = Convert.ToInt32(txt_aid.Text);
                string Atype = cmb_accountype.Text;
                int balance = Convert.ToInt32(txt_balance.Text);

                Account obj = new Account();
                obj.CustomerID = id; ;
                obj.AccountType = Atype;
                obj.AccountBalance = balance;


                AccountDAL dal = new AccountDAL();
                int id1 = dal.AddAccount(obj);
                MessageBox.Show("Account Added :" + id1);





            }
        }

       

        private void New_Account_Load(object sender, EventArgs e)
        {
            cmb_accountype.Items.Add("Savings");
            cmb_accountype.Items.Add("current");
            txt_aid.Text = cid.CustomerID.ToString();
            txt_aid.Enabled = false;

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            New n = new New();
            n.Show();
        }
    }
}
