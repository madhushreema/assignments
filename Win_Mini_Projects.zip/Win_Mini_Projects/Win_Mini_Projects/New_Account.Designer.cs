﻿namespace Win_Mini_Projects
{
    partial class New_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_aid = new System.Windows.Forms.Label();
            this.lbl_atype = new System.Windows.Forms.Label();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.btn_reset = new System.Windows.Forms.Button();
            this.txt_aid = new System.Windows.Forms.TextBox();
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.cmb_accountype = new System.Windows.Forms.ComboBox();
            this.btn_back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_aid
            // 
            this.lbl_aid.AutoSize = true;
            this.lbl_aid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aid.Location = new System.Drawing.Point(34, 31);
            this.lbl_aid.Name = "lbl_aid";
            this.lbl_aid.Size = new System.Drawing.Size(96, 17);
            this.lbl_aid.TabIndex = 0;
            this.lbl_aid.Text = "CustomerID:";
            // 
            // lbl_atype
            // 
            this.lbl_atype.AutoSize = true;
            this.lbl_atype.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_atype.Location = new System.Drawing.Point(37, 78);
            this.lbl_atype.Name = "lbl_atype";
            this.lbl_atype.Size = new System.Drawing.Size(112, 17);
            this.lbl_atype.TabIndex = 1;
            this.lbl_atype.Text = "Account Type:";
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_balance.Location = new System.Drawing.Point(37, 121);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(71, 17);
            this.lbl_balance.TabIndex = 2;
            this.lbl_balance.Text = "Balance:";
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_reset.Location = new System.Drawing.Point(161, 186);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 33);
            this.btn_reset.TabIndex = 4;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // txt_aid
            // 
            this.txt_aid.Location = new System.Drawing.Point(155, 30);
            this.txt_aid.Name = "txt_aid";
            this.txt_aid.Size = new System.Drawing.Size(140, 20);
            this.txt_aid.TabIndex = 5;
            // 
            // txt_balance
            // 
            this.txt_balance.Location = new System.Drawing.Point(155, 121);
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.Size = new System.Drawing.Size(140, 20);
            this.txt_balance.TabIndex = 7;
            // 
            // btn_add
            // 
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_add.Location = new System.Drawing.Point(290, 186);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 33);
            this.btn_add.TabIndex = 8;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // cmb_accountype
            // 
            this.cmb_accountype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_accountype.FormattingEnabled = true;
            this.cmb_accountype.Location = new System.Drawing.Point(155, 74);
            this.cmb_accountype.Name = "cmb_accountype";
            this.cmb_accountype.Size = new System.Drawing.Size(140, 21);
            this.cmb_accountype.TabIndex = 12;
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(231, 226);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(64, 23);
            this.btn_back.TabIndex = 15;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // New_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(453, 261);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.cmb_accountype);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_balance);
            this.Controls.Add(this.txt_aid);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.lbl_balance);
            this.Controls.Add(this.lbl_atype);
            this.Controls.Add(this.lbl_aid);
            this.Name = "New_Account";
            this.Text = "New_Account:";
            this.Load += new System.EventHandler(this.New_Account_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_aid;
        private System.Windows.Forms.Label lbl_atype;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.TextBox txt_aid;
        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.ComboBox cmb_accountype;
        private System.Windows.Forms.Button btn_back;
    }
}