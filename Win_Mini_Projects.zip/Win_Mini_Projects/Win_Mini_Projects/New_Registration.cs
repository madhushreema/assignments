﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Mini_Projects
{
    public partial class New_Registration : Form
    {
        public New_Registration()
        {
            InitializeComponent();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if (txt_name.Text == string.Empty)
            {

                MessageBox.Show("Enter name");

            }
            else if (txt_email.Text == string.Empty)
            {
                MessageBox.Show("Enter Email");
            }
            else if (txt_phone.Text == string.Empty)
            {
                MessageBox.Show("Entre Phone");
            }
            else if(txt_pass.Text==string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else if (cmb_gender.Text==string.Empty)
            {

                MessageBox.Show("Enter Gender");
            }
                    else
            {
                string name = txt_name.Text;
                string email = txt_email.Text;
                string phone = txt_phone.Text;
                string gender = cmb_gender.Text;
                string password = txt_pass.Text;
                Customer obj = new Customer();
                obj.CustomerName = name;
                obj.CustomerEmail = email;
                obj.CustomerPhone = phone;
                obj.CustomerGender = gender;
                obj.CustomerPassword = password;

                CustomerDAL dal = new CustomerDAL();
                int id = dal.AddCustomer(obj);
                MessageBox.Show("Customer Added :" + id);

                New h = new New();
                h.Show();
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_name.Text = String.Empty;
            txt_email.Text = string.Empty;
            txt_phone.Text = string.Empty;
            cmb_gender.Text = string.Empty;
            txt_pass.Text = string.Empty;

        }

        private void New_Registration_Load(object sender, EventArgs e)
        {
            cmb_gender.Items.Add("Female");
            cmb_gender.Items.Add("Male");
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }
    }

        
    }


