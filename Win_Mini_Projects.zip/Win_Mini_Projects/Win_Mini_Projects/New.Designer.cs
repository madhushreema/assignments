﻿namespace Win_Mini_Projects
{
    partial class New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newaccount = new System.Windows.Forms.Button();
            this.btn_myaccount = new System.Windows.Forms.Button();
            this.btn_newtransaction = new System.Windows.Forms.Button();
            this.btn_mytrasaction = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newaccount
            // 
            this.btn_newaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newaccount.Location = new System.Drawing.Point(82, 40);
            this.btn_newaccount.Name = "btn_newaccount";
            this.btn_newaccount.Size = new System.Drawing.Size(161, 47);
            this.btn_newaccount.TabIndex = 0;
            this.btn_newaccount.Text = "New_Account";
            this.btn_newaccount.UseVisualStyleBackColor = true;
            this.btn_newaccount.Click += new System.EventHandler(this.btn_newaccount_Click);
            // 
            // btn_myaccount
            // 
            this.btn_myaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_myaccount.Location = new System.Drawing.Point(372, 40);
            this.btn_myaccount.Name = "btn_myaccount";
            this.btn_myaccount.Size = new System.Drawing.Size(149, 47);
            this.btn_myaccount.TabIndex = 1;
            this.btn_myaccount.Text = "My_Account";
            this.btn_myaccount.UseVisualStyleBackColor = true;
            this.btn_myaccount.Click += new System.EventHandler(this.btn_myaccount_Click);
            // 
            // btn_newtransaction
            // 
            this.btn_newtransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtransaction.Location = new System.Drawing.Point(82, 145);
            this.btn_newtransaction.Name = "btn_newtransaction";
            this.btn_newtransaction.Size = new System.Drawing.Size(161, 45);
            this.btn_newtransaction.TabIndex = 2;
            this.btn_newtransaction.Text = "New_Transaction";
            this.btn_newtransaction.UseVisualStyleBackColor = true;
            this.btn_newtransaction.Click += new System.EventHandler(this.btn_newtransaction_Click);
            // 
            // btn_mytrasaction
            // 
            this.btn_mytrasaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mytrasaction.Location = new System.Drawing.Point(383, 145);
            this.btn_mytrasaction.Name = "btn_mytrasaction";
            this.btn_mytrasaction.Size = new System.Drawing.Size(138, 45);
            this.btn_mytrasaction.TabIndex = 3;
            this.btn_mytrasaction.Text = "My_Transaction";
            this.btn_mytrasaction.UseVisualStyleBackColor = true;
            this.btn_mytrasaction.Click += new System.EventHandler(this.btn_mytrasaction_Click);
            // 
            // New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(595, 261);
            this.Controls.Add(this.btn_mytrasaction);
            this.Controls.Add(this.btn_newtransaction);
            this.Controls.Add(this.btn_myaccount);
            this.Controls.Add(this.btn_newaccount);
            this.Name = "New";
            this.Text = "New";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_newaccount;
        private System.Windows.Forms.Button btn_myaccount;
        private System.Windows.Forms.Button btn_newtransaction;
        private System.Windows.Forms.Button btn_mytrasaction;
    }
}