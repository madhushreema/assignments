﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsADO
{
    public partial class frm_show : Form
    {
        public frm_show()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            try
            {
                customerDAL dal = new customerDAL();
                string city = txt_city.Text;
                List<customer> list = dal.ShowStudent(city);
                dg_customer.DataSource = list;
            }
            catch(System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Sql Error");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            finally
            {

                MessageBox.Show("Finally Block");
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {try
            {
                customerDAL dal = new customerDAL();
                string key = txt_search.Text;
                List<customer> list = dal.serachcustomer(key);
                dg_customer.DataSource = list;
            }catch(System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Sql Error");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            finally
            {

                MessageBox.Show("Finally Block");
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_city.Text = string.Empty;
            txt_search.Text = string.Empty;
            dg_customer.DataSource = null;
        }
    }
}
