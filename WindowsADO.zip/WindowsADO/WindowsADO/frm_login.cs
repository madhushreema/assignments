﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsADO
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_id.Text);
            string password = txt_pass.Text;
            try
            {

                customerDAL dal = new customerDAL();
                bool status = dal.Login(id, password);
                if (status)
                {
                    MessageBox.Show("Valid User");


                }
                else
                {
                    MessageBox.Show("Invalid User");
                }

            }
            catch (System.Data.SqlClient.SqlException )
            {
                MessageBox.Show("Sql Error");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            finally
            {

                MessageBox.Show("Finally Block");
            }
            Form1 f = new Form1();
            f.Show();
            
        }

        private void btn_login2_Click(object sender, EventArgs e)
        {



            string id = txt_id.Text;
            string password = txt_pass.Text;
            try
            {
                customerDAL dal = new customerDAL();
                bool status = dal.LoginSqlInjuction(id, password);
                if (status)
                {
                    MessageBox.Show("Valid User");
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }
            }catch(System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Sql Error");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            finally
            {

                MessageBox.Show("Finally Block");
            }

        }
            
    }
    
}
