﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsADO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (txt_name.Text == string.Empty)
            {

                MessageBox.Show("Enter name");

            }
            else if (txt_pass.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else if (txt_city.Text == string.Empty)
            {
                MessageBox.Show("Entre city");
            }
            else if (txt_email.Text == string.Empty)

            {
                MessageBox.Show("Enter Email");
            }
            else if (txt_add.Text == string.Empty)
            {

                MessageBox.Show("Enter address ");
            }
            else
            {
                string name = txt_name.Text;

                string password = txt_pass.Text;
                string city = txt_city.Text;
                string address = txt_add.Text;
                string phone = txt_phone.Text;
                string email = txt_email.Text;

                customer obj = new customer();
                obj.cname = name;

                obj.cpassword = password;
                obj.ccity = city;
                obj.caddress = address;
                obj.cphone = phone;
                obj.cemailid = email;

                try
                {

                    customerDAL dal = new customerDAL();
                    int id = dal.AddCustomer(obj);
                    MessageBox.Show("Student Added :" + id);
                }catch(System.Data.SqlClient.SqlException)
                {
                    MessageBox.Show("Sql Error");
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }

                finally
                {

                    MessageBox.Show("Finally Block");
                }
            }
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("Enter correct ID");
            }
            else
            {
                int Id = Convert.ToInt32(txt_id.Text);

                try
                {
                    customerDAL dal = new customerDAL();
                    customer c = dal.find(Id);
                    if (c != null)
                    {
                        txt_name.Text = c.cname;
                        txt_pass.Text = c.cpassword;
                        txt_city.Text = c.ccity;
                        txt_add.Text = c.caddress;
                        txt_phone.Text = c.cphone;
                        txt_email.Text = c.cemailid;

                    }
                    else
                    {
                        MessageBox.Show("not found");

                    }
                }
                catch (System.Data.SqlClient.SqlException)
                {
                    MessageBox.Show("Sql Error");
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }

                finally
                {

                    MessageBox.Show("Finally Block");
                }
                }




        }

        private void btn_update_Click(object sender, EventArgs e)
        {


            if (txt_id.Text == String.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_city.Text == string.Empty)
            {
                MessageBox.Show("Enter city");

            }
            else if (txt_pass.Text == string.Empty)
            {
                MessageBox.Show("Enter Password ");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                string city = txt_city.Text;
                string password = txt_pass.Text;

                try
                {
                    customerDAL dal = new customerDAL();
                    bool status = dal.update(ID, city, password);
                    if (status)
                    {
                        MessageBox.Show("Updated");
                    }
                    else
                    {
                        MessageBox.Show("Not Updated");
                    }
                }catch(System.Data.SqlClient.SqlException)
                {
                    MessageBox.Show("Sql Error");
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }

                finally
                {

                    MessageBox.Show("Finally Block");
                }
            }

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int id = Convert.ToInt32(txt_id.Text);
                try
                {
                    customerDAL dal = new customerDAL();
                    bool status = dal.Delete(id);
                    if (status)
                    {
                        MessageBox.Show("Deleted");
                    }
                    else
                    {
                        MessageBox.Show("Not Found");
                    }
                }catch(System.Data.SqlClient.SqlException)
                {
                    MessageBox.Show("Sql Error");
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }

                finally
                {

                    MessageBox.Show("Finally Block");
                }
            }




        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_id.Text = string.Empty;
            txt_name.Text = string.Empty;
            txt_add.Text = string.Empty;
            txt_email.Text = string.Empty;
            txt_phone.Text = string.Empty;
            txt_pass.Text = string.Empty;
            txt_city.Text = string.Empty;
        }

        private void btn_show_Click(object sender, EventArgs e)
        {try
            {
                frm_show f = new frm_show();
                f.Show();
            } catch(System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Sql Error");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            finally
            {

                MessageBox.Show("Finally Block");
            }
        }
    }
}

        
