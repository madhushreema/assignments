﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsADO
{
    class customer
    {

       public int cID { get; set; }
        public string cname { get; set; }
        public string cpassword { get; set; }
        public string ccity { get; set; }
        public string caddress { get; set; }
        public string cphone { get;set; }
        public string cemailid { get; set; }


    }
}
