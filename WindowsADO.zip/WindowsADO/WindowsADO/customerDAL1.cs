﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//Add
using System.Configuration;//D
using System.Data;
namespace WindowsADO
{
    class customerDAL
    {    SqlConnection con = new SqlConnection

                (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

            public int AddCustomer(customer cu)
            {
            try
            {
                SqlCommand com_cus_insert = new SqlCommand("proc_addcustomer", con);

                com_cus_insert.Parameters.AddWithValue("@name", cu.cname);
                com_cus_insert.Parameters.AddWithValue("@city", cu.ccity);
                com_cus_insert.Parameters.AddWithValue("@password", cu.cpassword);
                com_cus_insert.Parameters.AddWithValue("@address", cu.caddress);
                com_cus_insert.Parameters.AddWithValue("@phone", cu.cphone);
                com_cus_insert.Parameters.AddWithValue("@email", cu.cemailid);

                com_cus_insert.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_cus_insert.Parameters.Add(retdata);
                con.Open();
                com_cus_insert.ExecuteNonQuery();
                SqlCommand com_id = new SqlCommand("select @@identity", con);
                int ID = Convert.ToInt32(com_id.ExecuteScalar());
                con.Close();
                return ID;
            }finally
            {
                System.Windows.Forms.MessageBox.Show("Finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


        }

        public customer find(int ID)
        {
            try
            {

                SqlCommand com_find = new SqlCommand
                ("select * from tbl_customer where cid=@id", con);
                com_find.Parameters.AddWithValue("@id", ID);
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                if (dr.Read())
                {
                    customer c = new customer();
                    c.cID = dr.GetInt32(0);
                    c.cname = dr.GetString(1);
                    c.cpassword = dr.GetString(2);
                    c.ccity = dr.GetString(3);
                    c.caddress = dr.GetString(4);
                    c.cphone = dr.GetString(5);
                    c.cemailid = dr.GetString(6);



                    con.Close();
                    return c;



                }
                else
                {
                    return null;
                }
            }
            finally
            {



                System.Windows.Forms.MessageBox.Show("Finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }



            }
            



            public bool update(int ID, string city, string password)
            {

            try
            {
                SqlCommand com_update = new SqlCommand("update tbl_customer set ccity=@city,cpass=@password where cid=@id", con);
                com_update.Parameters.AddWithValue("@id", ID);
                com_update.Parameters.AddWithValue("@city", city);
                com_update.Parameters.AddWithValue("@password", password);
                con.Open();
                int count = com_update.ExecuteNonQuery();
                con.Close();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }finally
            {


                System.Windows.Forms.MessageBox.Show("Finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


            }

            public bool Delete(int id)
            {

            try
            {
                SqlCommand com_delete = new SqlCommand("delete tbl_customer where cid=@id", con);
                com_delete.Parameters.AddWithValue("@id", id);
                con.Open();
                int count = com_delete.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }




            }
            finally
            {


                System.Windows.Forms.MessageBox.Show("Finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


            }
            }

      




        public bool Login(int ID, string Password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);

                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@Password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(retdata);
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);

                if (count > 0)
                {

                    return true;
                }
                else
                { return false; }
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("Finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }




        public bool LoginSqlInjuction(string ID, string Password)
        {

            SqlCommand com_login = new SqlCommand("select count(*) from tbl_customer where cid='" + ID + "' and cpass='" + Password + "'", con);

           
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {

                return true;
            }
            else
            { return false; }
        }


        public List<customer> ShowStudent(string city)
        {

            SqlCommand com_customer = new SqlCommand("proc_showcustomer", con);
            com_customer.Parameters.AddWithValue("@city", city);
            com_customer.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_customer.ExecuteReader();

            List<customer> cuslist = new List<customer>();
            while (dr.Read())
            {

                customer obj = new customer();
                obj.cID = dr.GetInt32(0);
                obj.cname = dr.GetString(1);
                obj.cpassword = dr.GetString(2);
                obj.ccity = dr.GetString(3);
                obj.caddress = dr.GetString(4);

                
                obj.cphone = dr.GetString(5);
                obj.cemailid = dr.GetString(6);
                cuslist.Add(obj);

            }
            con.Close();
            return cuslist;

        }


        public List<customer>  serachcustomer(string Search)
        {
            SqlCommand com_search = new SqlCommand("proc_searchcustomer", con);
            com_search.Parameters.AddWithValue("@key", Search);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<customer> cuslist = new List<customer>();
            while (dr.Read())
            {
                customer obj = new customer();

                obj.cID = dr.GetInt32(0);
                obj.cname = dr.GetString(1);
                obj.cpassword = dr.GetString(2);
                obj.ccity = dr.GetString(3);
                obj.caddress = dr.GetString(4);
                 obj.cphone = dr.GetString(5);
                obj.cemailid = dr.GetString(6);
                cuslist.Add(obj);

            }
                con.Close();
            return cuslist;





        }





































    }

}
    




























