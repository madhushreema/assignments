﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Structure
{
    struct Book
    {

        private int Id;
        private string Name;


        public Book(int Id, string Name)
        {
            this.Id = Id;
            this.Name = Name;
        }


        public int PId
        {
            get { return this.Id; }
        }
        public string PName

        {
            get { return this.Name; }
            set { this.Name = value; }


        }
    }
}
