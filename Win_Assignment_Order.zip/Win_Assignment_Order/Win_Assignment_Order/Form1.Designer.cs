﻿namespace Win_Assignment_Order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_order = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_qty = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.txt_add = new System.Windows.Forms.TextBox();
            this.cmb_city = new System.Windows.Forms.ComboBox();
            this.rbd_cash = new System.Windows.Forms.RadioButton();
            this.rbd_card = new System.Windows.Forms.RadioButton();
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.lbl_add = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.rbd_net = new System.Windows.Forms.RadioButton();
            this.btn_save = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_order
            // 
            this.txt_order.Location = new System.Drawing.Point(178, 12);
            this.txt_order.Name = "txt_order";
            this.txt_order.Size = new System.Drawing.Size(100, 20);
            this.txt_order.TabIndex = 0;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(178, 55);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 1;
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(178, 105);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(100, 20);
            this.txt_id.TabIndex = 2;
            // 
            // txt_qty
            // 
            this.txt_qty.Location = new System.Drawing.Point(178, 143);
            this.txt_qty.Name = "txt_qty";
            this.txt_qty.Size = new System.Drawing.Size(100, 20);
            this.txt_qty.TabIndex = 3;
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(178, 174);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(100, 20);
            this.txt_price.TabIndex = 4;
            // 
            // txt_add
            // 
            this.txt_add.Location = new System.Drawing.Point(178, 212);
            this.txt_add.Name = "txt_add";
            this.txt_add.Size = new System.Drawing.Size(100, 20);
            this.txt_add.TabIndex = 5;
            // 
            // cmb_city
            // 
            this.cmb_city.FormattingEnabled = true;
            this.cmb_city.Location = new System.Drawing.Point(178, 266);
            this.cmb_city.Name = "cmb_city";
            this.cmb_city.Size = new System.Drawing.Size(121, 21);
            this.cmb_city.TabIndex = 6;
//            this.cmb_city.SelectedIndexChanged += new System.EventHandler(this.cmb_city_SelectedIndexChanged);
            // 
            // rbd_cash
            // 
            this.rbd_cash.AutoSize = true;
            this.rbd_cash.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbd_cash.Location = new System.Drawing.Point(409, 157);
            this.rbd_cash.Name = "rbd_cash";
            this.rbd_cash.Size = new System.Drawing.Size(58, 21);
            this.rbd_cash.TabIndex = 7;
            this.rbd_cash.TabStop = true;
            this.rbd_cash.Text = "Cash";
            this.rbd_cash.UseVisualStyleBackColor = true;
            // 
            // rbd_card
            // 
            this.rbd_card.AutoSize = true;
            this.rbd_card.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbd_card.Location = new System.Drawing.Point(409, 194);
            this.rbd_card.Name = "rbd_card";
            this.rbd_card.Size = new System.Drawing.Size(56, 21);
            this.rbd_card.TabIndex = 8;
            this.rbd_card.TabStop = true;
            this.rbd_card.Text = "Card";
            this.rbd_card.UseVisualStyleBackColor = true;
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderid.Location = new System.Drawing.Point(12, 12);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(84, 25);
            this.lbl_orderid.TabIndex = 9;
            this.lbl_orderid.Text = "OrderId:";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(12, 55);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(160, 25);
            this.lbl_customername.TabIndex = 10;
            this.lbl_customername.Text = "CustomerName :";
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemid.Location = new System.Drawing.Point(17, 105);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(74, 25);
            this.lbl_itemid.TabIndex = 11;
            this.lbl_itemid.Text = "ItemID:";
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemqty.Location = new System.Drawing.Point(17, 138);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(86, 25);
            this.lbl_itemqty.TabIndex = 15;
            this.lbl_itemqty.Text = "ItemQty:";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemprice.Location = new System.Drawing.Point(17, 174);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(99, 25);
            this.lbl_itemprice.TabIndex = 16;
            this.lbl_itemprice.Text = "ItemPrice:";
            // 
            // lbl_add
            // 
            this.lbl_add.AutoSize = true;
            this.lbl_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_add.Location = new System.Drawing.Point(22, 218);
            this.lbl_add.Name = "lbl_add";
            this.lbl_add.Size = new System.Drawing.Size(97, 25);
            this.lbl_add.TabIndex = 17;
            this.lbl_add.Text = "ItemAddr:";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_city.Location = new System.Drawing.Point(22, 273);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(73, 25);
            this.lbl_city.TabIndex = 18;
            this.lbl_city.Text = "O_City";
            // 
            // rbd_net
            // 
            this.rbd_net.AutoSize = true;
            this.rbd_net.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbd_net.Location = new System.Drawing.Point(409, 223);
            this.rbd_net.Name = "rbd_net";
            this.rbd_net.Size = new System.Drawing.Size(80, 21);
            this.rbd_net.TabIndex = 19;
            this.rbd_net.TabStop = true;
            this.rbd_net.Text = "NetBank";
            this.rbd_net.UseVisualStyleBackColor = true;
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(409, 266);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(129, 41);
            this.btn_save.TabIndex = 20;
            this.btn_save.Text = "Submit";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 339);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.rbd_net);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_add);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbl_orderid);
            this.Controls.Add(this.rbd_card);
            this.Controls.Add(this.rbd_cash);
            this.Controls.Add(this.cmb_city);
            this.Controls.Add(this.txt_add);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.txt_qty);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_order);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_order;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.TextBox txt_qty;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.TextBox txt_add;
        private System.Windows.Forms.ComboBox cmb_city;
        private System.Windows.Forms.RadioButton rbd_cash;
        private System.Windows.Forms.RadioButton rbd_card;
        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.Label lbl_add;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.RadioButton rbd_net;
        private System.Windows.Forms.Button btn_save;
    }
}

