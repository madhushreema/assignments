﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Assignment_Order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if(txt_order.Text==string.Empty)
            {

                MessageBox.Show("Entre correct OrderId");

            }
            else if(txt_name.Text ==String.Empty)
            {
                MessageBox.Show("entre correct CustomerName");
            }
            else if(txt_id.Text==string.Empty)
            {
                MessageBox.Show("Enter ItemId");
            }
            else if(txt_qty.Text==string.Empty)
            {
                MessageBox.Show("Entre correct ItemQty");

            }
            else if(txt_price.Text==string.Empty)
            {
                MessageBox.Show("Enter Corretc Price");
            }
            else if(txt_add.Text==string.Empty)
            {
                MessageBox.Show("Entre Correct Address");
            }

            else if (rbd_cash.Checked == false && rbd_card.Checked == false && rbd_net.Checked == false)
            {
                MessageBox.Show("Select Your Payment  :");
            }
            else if (cmb_city.Text == string.Empty)
            {
                MessageBox.Show("Select city : ");
            }
            else
            {


                int id = Convert.ToInt32(txt_order.Text);

                string name = txt_name.Text;
                
                int iid = Convert.ToInt32(txt_id.Text);
                int qty = Convert.ToInt32(txt_qty.Text);
                int price = Convert.ToInt32(txt_price.Text);
                string add = txt_add.Text;
               // string city = txt_city.Text;
                string city = cmb_city.Text;
                
            
            
                string pay = string.Empty;
                if (rbd_cash.Checked)
                {
                    pay = "cash";
                }
                else if (rbd_card.Checked)
                {
                    pay = "card";
                }

                else
                {
                    pay = "Net";
                }

                //MessageBox.Show(pay);


                Order o = new Order(id,name,iid,qty,price,add,city,pay);
               int Val= o.getOrderValue();
                MessageBox.Show("val" +Val);
            }

        }

      

        private void Form1_Load(object sender, EventArgs e)
        {

            cmb_city.Items.Add("Hyd");
            cmb_city.Items.Add("Banglore");
            cmb_city.Items.Add("Andra");

        }
    }
}
