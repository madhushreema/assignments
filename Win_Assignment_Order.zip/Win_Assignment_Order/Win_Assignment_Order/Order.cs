﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Assignment_Order
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        private int ItemId;
        private int Itemqty;
        private int ItemPrice;
        private string Address;
        private string City;
        private string PsymentOption;

        public Order(int OrderId,string CustomerName, int ItemId, int Itemqty, int ItemPrice, string Address, string City, string PsymentOption)
        {
            this.OrderId = OrderId;
            this.CustomerName = CustomerName;
            this.ItemId = ItemId;
            this.Itemqty = Itemqty;
            this.ItemPrice = ItemPrice;
            this.Address = Address;
            this.City = City;
            this.PsymentOption = PsymentOption;
        }

        public int getOrderValue()
        {
            int val = this.ItemPrice * this.Itemqty;
            return val;
        }


    }
}
