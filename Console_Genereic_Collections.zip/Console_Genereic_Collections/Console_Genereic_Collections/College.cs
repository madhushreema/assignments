﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Genereic_Collections
{
    class College
    {
        public void onleave(int id,string reason)
        {
            Console.WriteLine("College class : student on leave :" + id + " ," + reason);

        }
        private int CollegeId;
        private string CollegeName;
         public College(int CollegeId,string CollegeName)
        {
            this.CollegeId = CollegeId;
            this.CollegeName = CollegeName;
        }

        private List<Student> studentList = new List<Student>();







        public void AddStudent(Student s)
        {

            Student.delleave d = new Student.delleave(this.onleave);
            s.evtleave += d;
            studentList.Add(s);
        }







        public Student Find(int ID)
        {
            foreach (Student s in studentList)
            {
                if (s.PStudentId == ID)
                { return s; }
            }
            return null;


   }


           public bool Remove(int ID)
        {
            foreach(Student s in studentList)
            {
                if(s.PStudentId==ID)
                {
                    studentList.Remove(s);
                    return true;
                }
            }
            return false;
        }




        public void ShowAll()
        {
            foreach(Student s in studentList)
            {
                Console.WriteLine(s.PStudentId + " " + s.PStudentName + " " + s.PStudentCity);
            }
        }





    }
}
