﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Genereic_Collections
{
    class Student
    {
        public delegate void delleave(int id,string reason);
        public event delleave evtleave;
        private int StudentId;
        private string StudentName;
        private string StudentCity;
        private static int count = 100;


        public Student(string StudentName, string StudentCity)
        {
            Student.count++;
            this.StudentId = Student.count;
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;

        }
        public int PStudentId
        {
            get
            {
                return this.StudentId;
            }
        }
        public string PStudentName
        {
            get { return this.StudentName; }
        }
        public string PStudentCity
        {
            get { return this.StudentCity; }
        }
        public void TakeLeave(string Reason)
        {

            if(evtleave!=null)
            {

                this.evtleave(this.StudentId, Reason);

            }
            Console.WriteLine("Student on leave :" + this.StudentId + " , Reason: " + Reason);
        }
    }
}
