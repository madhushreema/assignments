﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_salary_calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_sal_Click(object sender, EventArgs e)
        {
            if(txt_day.Text==String.Empty)
            {
                MessageBox.Show("Enter correct Days:");
            }
            else if(txt_psal.Text==string.Empty)
            {
                MessageBox.Show("Entre Correct Per Day Salary :");
            }
            else
            {
                int days = Convert.ToInt32(txt_day.Text);
                int Per_Day_sal = Convert.ToInt32(txt_psal.Text);


                SalaryLibrary.Salary obj = new SalaryLibrary.Salary();
                int total = obj.GetSalary(days, Per_Day_sal);
                lbl_salary.Text = total.ToString();



            }
        }
    }
}
