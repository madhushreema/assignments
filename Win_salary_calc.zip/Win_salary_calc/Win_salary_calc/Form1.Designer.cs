﻿namespace Win_salary_calc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_day = new System.Windows.Forms.Label();
            this.lbl_sal = new System.Windows.Forms.Label();
            this.txt_day = new System.Windows.Forms.TextBox();
            this.txt_psal = new System.Windows.Forms.TextBox();
            this.btn_sal = new System.Windows.Forms.Button();
            this.lbl_salary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_day
            // 
            this.lbl_day.AutoSize = true;
            this.lbl_day.Location = new System.Drawing.Point(41, 38);
            this.lbl_day.Name = "lbl_day";
            this.lbl_day.Size = new System.Drawing.Size(34, 13);
            this.lbl_day.TabIndex = 0;
            this.lbl_day.Text = "Days:";
            // 
            // lbl_sal
            // 
            this.lbl_sal.AutoSize = true;
            this.lbl_sal.Location = new System.Drawing.Point(44, 87);
            this.lbl_sal.Name = "lbl_sal";
            this.lbl_sal.Size = new System.Drawing.Size(80, 13);
            this.lbl_sal.TabIndex = 1;
            this.lbl_sal.Text = "Per Day Salary:";
            // 
            // txt_day
            // 
            this.txt_day.Location = new System.Drawing.Point(214, 30);
            this.txt_day.Name = "txt_day";
            this.txt_day.Size = new System.Drawing.Size(100, 20);
            this.txt_day.TabIndex = 2;
            // 
            // txt_psal
            // 
            this.txt_psal.Location = new System.Drawing.Point(214, 84);
            this.txt_psal.Name = "txt_psal";
            this.txt_psal.Size = new System.Drawing.Size(100, 20);
            this.txt_psal.TabIndex = 3;
            // 
            // btn_sal
            // 
            this.btn_sal.Location = new System.Drawing.Point(137, 192);
            this.btn_sal.Name = "btn_sal";
            this.btn_sal.Size = new System.Drawing.Size(107, 23);
            this.btn_sal.TabIndex = 4;
            this.btn_sal.Text = "Get Salary";
            this.btn_sal.UseVisualStyleBackColor = true;
            this.btn_sal.Click += new System.EventHandler(this.btn_sal_Click);
            // 
            // lbl_salary
            // 
            this.lbl_salary.AutoSize = true;
            this.lbl_salary.Location = new System.Drawing.Point(333, 181);
            this.lbl_salary.Name = "lbl_salary";
            this.lbl_salary.Size = new System.Drawing.Size(39, 13);
            this.lbl_salary.TabIndex = 5;
            this.lbl_salary.Text = "Salary:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 314);
            this.Controls.Add(this.lbl_salary);
            this.Controls.Add(this.btn_sal);
            this.Controls.Add(this.txt_psal);
            this.Controls.Add(this.txt_day);
            this.Controls.Add(this.lbl_sal);
            this.Controls.Add(this.lbl_day);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_day;
        private System.Windows.Forms.Label lbl_sal;
        private System.Windows.Forms.TextBox txt_day;
        private System.Windows.Forms.TextBox txt_psal;
        private System.Windows.Forms.Button btn_sal;
        private System.Windows.Forms.Label lbl_salary;
    }
}

