﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq_Assignmet06
{
    class Employee
    {
        public int EmpID { get; set;}
        public string EmpName { get; set; }

        public int Salary { get; set; }
    
        public int EmpExp { get; set; }
        public string EmpCity { get; set; }


    }
}
