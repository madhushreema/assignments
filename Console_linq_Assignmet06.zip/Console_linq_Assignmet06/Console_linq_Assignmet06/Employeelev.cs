﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq_Assignmet06
{
    class Employeelev
    {

        public int LeaveId { get; set; }
        public string LType { get; set; }

        public string Reason { get; set; }
        public int EmpID { get; set; }
    }
}
