﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq_Assignmet06
{
    class Program
    {
        static void Main(string[] args)
        {
            List < Employee > emplist= new List<Employee>();
            emplist.Add(new Employee { EmpID = 1, EmpName = "ABC",Salary=51000,EmpExp=2, EmpCity = "Tumkur" });
            emplist.Add(new Employee { EmpID = 2, EmpName = "Kala", Salary = 60000, EmpExp = 9, EmpCity = "BGL" });
            emplist.Add(new Employee { EmpID = 3, EmpName = "Sandya", Salary = 85000, EmpExp = 4, EmpCity = "BGL" });
            emplist.Add(new Employee { EmpID = 4, EmpName = "Aagu", Salary = 25000, EmpExp = 5, EmpCity = "Tumkur" });

            List<Employeelev> empl = new List<Employeelev>();

            empl.Add(new Employeelev { EmpID = 1, LeaveId = 100, LType = "dwknjkn", Reason = "Trip" });


            empl.Add(new Employeelev { EmpID = 1, LeaveId = 101, LType = "Summer", Reason = "Trip" });


            empl.Add(new Employeelev { EmpID = 2, LeaveId = 102, LType = "sdgsfg", Reason = "Fever" });


            empl.Add(new Employeelev { EmpID = 3, LeaveId = 103, LType = "djhg", Reason = "Festival" });


            var count = (from e in emplist
                         where e.EmpExp >= 5
                         select e).Count();
            Console.WriteLine("Count of Employee who has more Than 5 years of experiences:\n" +count);



            int  emp = 50000;
            var q = from e in emplist
                    where e.Salary > emp
                    select e;
            Console.WriteLine("List of Employee whose Salary is more than 50000:");
            foreach (var y in q)
            {
                Console.WriteLine(y.EmpName);


            }

            string city = "BGL";
            var w = from e in emplist
                    where e.EmpCity == city
                    select e;

            Console.WriteLine("Employees who are from banglore are:");

            foreach(var y in w)
            {
                Console.WriteLine(y.EmpName);
            }



            var d = from e in emplist
                    where e.EmpName.StartsWith("A")
                    select e;
            Console.WriteLine("Employee Deatils whoes name starts with A are :");
            foreach(var y in d)
            {
                Console.WriteLine(y.EmpID + " " + y.EmpName + " " + y.Salary);
            }


            var join = from e in emplist
                       join l in empl
                       on e.EmpID equals l.EmpID
                       select new { EID = e.EmpID, ENAME = e.EmpName, EEXP = e.EmpExp, Salary = e.Salary, LID = l.LeaveId, LType = l.LType, Reason = l.Reason };



            Console.WriteLine("Employee Join Deatails who are in Leave:");

            foreach(var v in join)
            {

                Console.WriteLine(v.EID + " " + v.ENAME + " " + v.EEXP + " " + v.Salary + " " + v.LID + " " + v.LType + " " + v.Reason);

            }

            Console.WriteLine("-----------LAMBDA--------------");


            var data = emplist.Where((e) => e.EmpExp >= 5);
            Console.WriteLine("Count of Employee who has more Than 5 years of experiences:\n");
            foreach (var x in data)
            {
                Console.WriteLine(x.EmpID + " " + x.EmpName);


            }
            var data1 = emplist.Where((e) => e.Salary >= 50000);
            Console.WriteLine("Count of Employee who salary more Than 50000:\n");
            foreach (var x in data1)
            {
                Console.WriteLine(x.EmpID + " " + x.EmpName);


            }

            var data2 = emplist.Where((e) => e.EmpCity=="BGL");
            Console.WriteLine("List of employees from banglore:\n");
            foreach (var x in data2)
            {
                Console.WriteLine(x.EmpName);


            }

            var data3 = emplist.Where((e) => e.EmpName.StartsWith("A"));
            Console.WriteLine("Employee Deatils whoes name starts with A are :");
            foreach (var y in data3)
            {
                Console.WriteLine(y.EmpID + " " + y.EmpName + " ");

             }


            var joindata = emplist.Join(empl, (e) => e.EmpID, (l) => l.EmpID, (e, l) => new
            {
                EMPID = e.EmpID,
                ENAME = e.EmpName,
                EEXP = e.EmpExp,
                Salary = e.Salary,
                LID = l.LeaveId,
                LType = l.LType,
                Reason = l.Reason

            });

            Console.WriteLine("Employee Join Deatails who are in Leave:");
            foreach (var y in joindata)
            {

                Console.WriteLine(y.EMPID + " " + y.ENAME + " " + y.EEXP + " " + y.Salary + " " + y.LID + " " + y.LType+" " + y.Reason);
            }





            Console.ReadLine();

        }
    }
}
