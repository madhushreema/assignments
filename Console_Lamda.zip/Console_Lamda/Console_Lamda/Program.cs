﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Lamda
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerId = 1, CustomerAge = 23, CustomerCity = "BGL", CustomerName = "ABC" });
            custlist.Add(new Customer { CustomerId = 2, CustomerAge = 27, CustomerCity = "GUL", CustomerName = "Ganga" });

            custlist.Add(new Customer { CustomerId = 3, CustomerAge = 34, CustomerCity = "Tumkur", CustomerName = "Tanu" });
            custlist.Add(new Customer { CustomerId = 4, CustomerAge = 28, CustomerCity = "BGL", CustomerName = "Thara" });
            custlist.Add(new Customer { CustomerId = 5, CustomerAge = 45, CustomerCity = "BGL", CustomerName = "Fathima" });
            custlist.Add(new Customer { CustomerId = 6, CustomerAge = 45, CustomerCity = "Sagara", CustomerName = "Fathima" });


            List<Order> ordlist = new List<Order>();


            ordlist.Add(new Order { CustomerID = 1, ItemName = "Pen", ItemPrice = 23, OrderID = 100 });
            ordlist.Add(new Order { CustomerID = 2, ItemName = "Bag", ItemPrice = 3400, OrderID = 200 });
            ordlist.Add(new Order { CustomerID = 3, ItemName = "Laptop", ItemPrice = 34000, OrderID = 300 });
            ordlist.Add(new Order { CustomerID = 4, ItemName = "Mouse", ItemPrice = 560, OrderID = 400 });
            ordlist.Add(new Order { CustomerID = 5, ItemName = "TV", ItemPrice = 890, OrderID = 500 });
            ordlist.Add(new Order { CustomerID = 1, ItemName = "TV", ItemPrice = 890, OrderID = 500 });
            ordlist.Add(new Order { CustomerID = 1, ItemName = "TV", ItemPrice = 890, OrderID = 545 });

            var data = custlist.Where((c) => c.CustomerCity == "BGL");
            foreach (var x in data)
            {
                Console.WriteLine(x.CustomerId + " " + x.CustomerName);
            }






            var count = custlist.Count((c) => c.CustomerCity == "BGL");
            Console.WriteLine(count);
            var obj = custlist.FirstOrDefault((c) => c.CustomerId == 1);



            if (obj != null)
            {
                Console.WriteLine(obj.CustomerId + " " + obj.CustomerName);


            }
            else
            {
                Console.WriteLine("Not Found");
            }
            var status = custlist.Exists((c) => c.CustomerId == 1);

            Console.WriteLine(status);







            var dataprojection = custlist.Where((c) => c.CustomerCity == "BGL").Select((s) => new { CID = s.CustomerId, CNAMe = s.CustomerName });
            foreach(var d in dataprojection)
            {
                Console.WriteLine(d.CID + " "+d.CNAMe);
            }









            var dataorderby = custlist.Where((c) => c.CustomerAge > 20).OrderBy((o) => obj.CustomerName).ThenByDescending((o1) => o1.CustomerCity);


            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.CustomerId + " " + d.CustomerName + " " + d.CustomerCity);
            }




            var groupdata = custlist.GroupBy((g) => g.CustomerCity).
                Select((s) => new
                {

                    city = s.Key,
                    Count = s.Count(),
                    avg = s.Average((a) => a.CustomerAge)


                });
            foreach(var x in groupdata)
            {
                Console.WriteLine(x.city + " " + x.Count + " " + x.avg);
            }



            var joindata = custlist.Join(ordlist, (c) => c.CustomerId,
                (o) => o.CustomerID,
                
                (c, o) => new
                {
                    CID = c.CustomerId,
            CNAM = c.CustomerName,
            OID = o.OrderID,
            Iname = o.ItemName,
            Iprice = o.ItemPrice


                });
            foreach(var x in joindata)
            {

                Console.WriteLine(x.CID + " " + x.CNAM + " " + x.OID + " " + x.Iname + " " + x.Iprice);
            }






            Console.ReadLine();
        }
       
        
    }
}
